import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BookingViewModel } from '../Model/BookingModel';

@Component({
  selector: 'app-get-all-resource',
  templateUrl: './get-all-resource.component.html',
  styleUrls: ['./get-all-resource.component.css']
})
export class GetAllResourceComponent implements OnInit {

  constructor(private http: HttpClient) { }
  resourceList: any;

  ngOnInit() { }

  getAllResources(form: any) {
    // let headers = new HttpHeaders();
    // headers.append('Content-Type', 'application/json');
    let params = new HttpParams().set("startTime", form.startDate).set("EndDateTime", form.endDate).set("Location", form.location);

    this.http.get("http://localhost:39521/api/resources", { params: params })
      .subscribe(
        (data) => {
          this.resourceList = data as string[];

          console.log(this.resourceList.body);
        }
      )
  }

  val: any;
  imageInfo(id: any) {
    this.val = id;

    console.log(id);
  }

  bookingViewModel: BookingViewModel

  bookResource(res: any, formValue: any) {

    // const emptyObj: BookingViewModel={startDate:"2019-02-08 12:00",endDate:"2019-02-08 12:00",firstName:'iyg',lastName:'iluhg',quantity:0,token:'liuyki'};
    const emptyObj: BookingViewModel = { startDate: '', endDate: '', firstName: '', lastName: '', quantity: 0, token: '' };

    this.bookingViewModel = emptyObj;
    this.bookingViewModel.startDate = formValue.startDate;
    this.bookingViewModel.endDate = formValue.endDate;
    this.bookingViewModel.quantity = 1;
    this.bookingViewModel.firstName = "Shivanshu";
    this.bookingViewModel.lastName = "Sharma";
    this.bookingViewModel.token = "TOKEN";

    console.log(emptyObj);

    this.http.post("http://localhost:39521/api/bookings/" + res.id, this.bookingViewModel)
      .subscribe(
        (data) => {
          this.resourceList = data as string[];

          console.log(this.resourceList.body);
        }
      )
  }
}