import { Component, OnInit } from '@angular/core';
import { User } from '../Classes/User';
import { LoginService } from '../Services/login.service';
import { Router } from '@angular/router';
import { UserViewModel } from '../Model/UserModel';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username: string;
  password: string;
  submitted = false;

  constructor(
    private router: Router,
    private loginService: LoginService) { }


  ngOnInit() {
    const token = localStorage.getItem('token');
    if (!isNullOrUndefined(token)) {
      localStorage.removeItem('token');
    }
  }

  user: User;

  onSubmit() {
    debugger;
    this.submitted = true;

    this.loginService.login(this.username, this.password)
      .subscribe((result: any ) => {
        debugger;
        if (!isNullOrUndefined(result)) {
          localStorage.setItem('Token', JSON.stringify((result.token)));
          localStorage.setItem('User ID', JSON.stringify(result.userId));
          localStorage.setItem('User Name', JSON.stringify(result.firstName));
          localStorage.setItem('User Email', JSON.stringify(result.mail));

          this.router.navigate(['resource']);
        }
      });
  }
}