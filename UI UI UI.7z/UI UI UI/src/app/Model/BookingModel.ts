export interface BookingViewModel
{
    startDate?: string;   
    endDate? : string;
    quantity: number;
    firstName :string;
    lastName: string;
    token : string;
}