﻿using System.Net;
using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using Microsoft.AspNetCore.Mvc;

namespace GCRieber.API.Controllers
{
    /// <summary>
    /// Healthcheck enpoint should be useable as a health and liveness check
    /// </summary>
    [Produces("application/json")]
    [Route("api/health")]
    public class HealthController : Controller
    {
        /// <summary>
        /// Returns the instance health
        /// </summary>
        /// <returns>Result model with status</returns>
        [HttpGet]
        public IResult Index()
        {
            return new Result { Status = Status.Success, Message = "GCRieber API is running", Body = "GCRieber API is running", Operation = Operation.Read, StatusCode = HttpStatusCode.OK};
        }
    }
}