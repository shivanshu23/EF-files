﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using GCRieber.API.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RestSharp;

namespace GCRieber.API.Controllers
{
    /// <summary>
    /// Resource's endpoint
    /// </summary>
    [Route("api")]
    [ApiController]
    //[Authorize]
    [AllowAnonymous]
    [EnableCors("*")]
    public class BookingsController : ControllerBase
    {
        private readonly ILogger _logger;
        readonly IConfiguration _configuration;
        private readonly ClaimsPrincipal _principal;
        private readonly PlanyoApiClient _planyoApiClient;

        /// <summary>
        /// Resources Controller
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="configuration"></param>
        /// <param name="principal"></param>
        public BookingsController(ILogger<ResourcesController> logger, IConfiguration configuration, IPrincipal principal)
        {
            _logger = logger;
            _configuration = configuration;
            _principal = principal as ClaimsPrincipal;
            _planyoApiClient = new PlanyoApiClient(_configuration);
        }

        /// <summary>
        /// List user reservations
        /// </summary>
        /// <returns>List of available Reservation</returns>
        [HttpGet("bookings")]
        [ProducesResponseType(typeof(List<Booking>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> ListReservation(DateTime startDateTime, DateTime endDateTime)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();
                var request = new RestRequest();
                request.AddParameter("start_time", startDateTime.ToString("yyyy-MM-dd HH:mm"));
                request.AddParameter("end_time", endDateTime.ToString("yyyy-MM-dd HH:mm"));
                request.AddParameter("user_email", activeUserEmail);
                // for getting the pricing info for all reservations
                request.AddParameter("detail_level", (int)DetailLevels.Price_Location);

                var response = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingListViewModel>>(request, PlanyoEndpoints.ListReservations);
                if (response.ResponseCode == 0)
                {
                    result.Body = response.Data;
                    result.Message = response.ResponseMessage;
                    result.StatusCode = HttpStatusCode.OK;
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while listing bookings of user");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// Delete booking
        /// </summary>
        /// <returns>Delete booking sucess message</returns>
        [HttpDelete]
        [Route("bookings/{bookingid}")]
        [ProducesResponseType(typeof(DeleteBookingDataViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> Delete(int bookingid)
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();
                request.AddParameter("reservation_id", bookingid);
                var dataResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<Booking>>(request, PlanyoEndpoints.GetReservationData);
                // Case if booking exists
                if (dataResponse.ResponseCode == 0)
                {
                    var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();
                    if (dataResponse.Data.Email.ToLower() == activeUserEmail.ToLower())
                    {
                        if (dataResponse.Data.Status == ReservationStatus.CancelByUser)
                        {
                            result.Status = Status.Fail;
                            result.Message = "Booking is already cancelled";
                            result.StatusCode = HttpStatusCode.OK;
                            _logger.LogWarning(result.Message);
                            return StatusCode((int)HttpStatusCode.OK, result);
                        }

                        request = new RestRequest();
                        request.AddParameter("reservation_id", bookingid);
                        //parameter for user cancelling the booking.
                        request.AddParameter("action", ReservationActions.UserCancel);

                        var cancelReservationResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<DeleteBookingDataViewModel>>(request, PlanyoEndpoints.DoReservationAction);
                        if (cancelReservationResponse.ResponseCode == 0)
                        {
                            result.Body = cancelReservationResponse.Data;
                            result.Message = cancelReservationResponse.ResponseMessage;
                            result.StatusCode = HttpStatusCode.OK;
                            return StatusCode((int)result.StatusCode, result);
                        }
                        result.Status = Status.Fail;
                        result.Message = cancelReservationResponse.ResponseMessage;
                        result.StatusCode = HttpStatusCode.BadRequest;
                        _logger.LogWarning(result.Message);
                        return StatusCode((int)HttpStatusCode.BadRequest, result);
                    }
                    result.Status = Status.Fail;
                    result.Message = "You are not authorize to delete other user booking";
                    result.StatusCode = HttpStatusCode.OK;
                    _logger.LogWarning(result.Message);
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                result.Status = Status.Fail;
                result.Message = dataResponse.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(result.Message);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while deleting booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }


        /// <summary>
        /// Modify User's Booking
        /// </summary>
        /// <returns>Modify booking sucess message</returns>
        [HttpPut]
        [Route("bookings/{bookingid}")]
        [ProducesResponseType(typeof(UpdateBookingResponseViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> ModifyBookings(int bookingid, [FromBody] UpdateBookingViewModel modifybooking)
        {
            var result = new Result
            {
                Operation = Operation.Update,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();
                request.AddParameter("reservation_id", bookingid);
                var dataResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<Booking>>(request, PlanyoEndpoints.GetReservationData);
                if (dataResponse.ResponseCode == 0)
                {
                    var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();
                    if (dataResponse.Data.Email == activeUserEmail)
                    {
                        if (dataResponse.Data.Status == ReservationStatus.CancelByUser) // other cancel checks
                        {
                            result.Status = Status.Fail;
                            result.Message = "Cancelled bookings cannot be modified";
                            result.StatusCode = HttpStatusCode.OK;
                            _logger.LogWarning(result.Message);
                            return StatusCode((int)HttpStatusCode.OK, result);
                        }
                        // Update booking details
                        request = new RestRequest();
                        request.AddParameter("reservation_id", bookingid);
                        request.AddParameter("resource_id", modifybooking.ResourceId);
                        request.AddParameter("start_time", modifybooking.StartTime.ToString("yyyy-MM-dd HH:mm"));
                        request.AddParameter("end_time", modifybooking.EndTime.ToString("yyyy-MM-dd HH:mm"));
                        request.AddParameter("prop_res_location", modifybooking.Location);

                        var updateBookingResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<UpdateBookingResponseViewModel>>(request, PlanyoEndpoints.ModifyReservation);
                        if (updateBookingResponse.ResponseCode == 0)
                        {
                            result.Body = updateBookingResponse.Data;
                            result.Message = updateBookingResponse.ResponseMessage;
                            result.StatusCode = HttpStatusCode.OK;
                            return StatusCode((int)result.StatusCode, result);
                        }
                        result.Status = Status.Fail;
                        result.Message = updateBookingResponse.ResponseMessage;
                        result.StatusCode = HttpStatusCode.BadRequest;
                        _logger.LogWarning(result.Message);
                        return StatusCode((int)HttpStatusCode.BadRequest, result);
                    }
                    result.Status = Status.Fail;
                    result.Message = "You are not authorize to modify other user's booking";
                    result.StatusCode = HttpStatusCode.OK;
                    _logger.LogWarning(result.Message);
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                result.Status = Status.Fail;
                result.Message = dataResponse.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(result.Message);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error while modifying booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        //THIS IS NOT THE MAIN ONE.
        /// <summary>
        /// New booking
        /// </summary>
        /// <returns>Make a new booking</returns>
        [HttpPost]
        [Route("{resourceId}/bookings")]
        [ProducesResponseType(typeof(List<BookingResponseViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> Bookings(int resourceId, [FromBody] BookingViewModel booking)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();

                var request = new RestRequest();
                request.AddParameter("email", activeUserEmail);
                //get user data
                var makeReservationResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<GetUserDataViewModel>>(request, PlanyoEndpoints.GetUserData);

                //If user Exists
                if (makeReservationResponse.ResponseCode == 0)
                {
                    request.AddParameter("resource_id", resourceId);
                    request.AddParameter("start_time", booking.Start_Date.ToString("yyyy-MM-dd HH:mm"));
                    request.AddParameter("end_time", booking.End_Date.ToString("yyyy-MM-dd HH:mm"));
                    request.AddParameter("quantity", booking.Quantity);
                    request.AddParameter("first_name", booking.First_name);
                    request.AddParameter("last_name", booking.Last_name);
                    //make reservation
                    var reservationResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingResponseViewModel>>(request, PlanyoEndpoints.MakeReservation);

                    if (reservationResponse.ResponseCode == 0)
                    {
                        if (reservationResponse.Data != null)
                        {
                            result.Body = reservationResponse.Data;
                            result.Message = reservationResponse.ResponseMessage;
                            result.StatusCode = HttpStatusCode.OK;
                        }
                        return StatusCode((int)result.StatusCode, result);
                    }

                    result.Status = Status.Fail;
                    result.Message = reservationResponse.ResponseMessage;
                    result.StatusCode = HttpStatusCode.BadRequest;
                    _logger.LogWarning(reservationResponse.ResponseMessage);
                    return StatusCode((int)HttpStatusCode.BadRequest, result);

                }
                //if user doesn't exist
                else
                {
                    request = new RestRequest();
                    request.AddParameter("email", activeUserEmail);
                    request.AddParameter("first_name", booking.First_name);
                    //add new user
                    var addUserResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<CreateUserDataViewModel>>(request, PlanyoEndpoints.AddUser);

                    if (addUserResponse.ResponseCode == 0)
                    {
                        request.AddParameter("resource_id", resourceId);
                        request.AddParameter("start_time", booking.Start_Date.ToString("yyyy-MM-dd HH:mm"));
                        request.AddParameter("end_time", booking.End_Date.ToString("yyyy-MM-dd HH:mm"));
                        request.AddParameter("quantity", booking.Quantity);
                        request.AddParameter("first_name", booking.First_name);
                        request.AddParameter("last_name", booking.Last_name);
                        //make reservation
                        var reservationResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingResponseViewModel>>(request, PlanyoEndpoints.MakeReservation);

                        if (reservationResponse.ResponseCode == 0)
                        {
                            if (reservationResponse.Data != null)
                            {
                                result.Body = reservationResponse.Data;
                                result.Message = reservationResponse.ResponseMessage;
                                result.StatusCode = HttpStatusCode.OK;
                            }
                            return StatusCode((int)result.StatusCode, result);
                        }

                        result.Status = Status.Fail;
                        result.Message = reservationResponse.ResponseMessage;
                        result.StatusCode = HttpStatusCode.BadRequest;
                        _logger.LogWarning(reservationResponse.ResponseMessage);
                        return StatusCode((int)HttpStatusCode.BadRequest, result);
                    }

                    else
                    {
                        result.Status = Status.Fail;
                        result.Message = "Error while creating user";
                        result.StatusCode = HttpStatusCode.BadRequest;
                        //_logger.LogWarning(reservationResponse.ResponseMessage);
                        return StatusCode((int)HttpStatusCode.BadRequest, result);
                    }
                }
            }

            catch (Exception e)
            {
                _logger.LogError(e, "Error while creating booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// Add booking payment details
        /// </summary>
        /// <returns>Add payment details for booking</returns>
        [HttpPost]
        [Route("/payments")]
        [ProducesResponseType(typeof(List<BookingPaymentResponseViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> AddPayment([FromBody] BookingPaymentViewModel payment)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();
                var request = new RestRequest();
                request.AddParameter("reservation_id", payment.ReservationId);
                request.AddParameter("payment_mode", payment.Payment_mode);
                request.AddParameter("payment_status", payment.Payment_status);
                request.AddParameter("payment_response_code", payment.Payment_response_code);
                request.AddParameter("transaction_id", payment.Transaction_id);
                request.AddParameter("transaction_status_text", payment.Transaction_status_text);
                request.AddParameter("amount", payment.Amount);
                request.AddParameter("currency", payment.Currency);

                var response = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingPaymentResponseViewModel>>(request, PlanyoEndpoints.ReservationPayment);
                if (response.ResponseCode == 0)
                {
                    result.Body = response.Data;
                    result.Message = response.ResponseMessage;
                    result.StatusCode = HttpStatusCode.OK;
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error while adding payment details for booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// List booking payment details
        /// </summary>
        /// <returns>List payment details for booking</returns>
        [HttpPost]
        [Route("/list_reservation_payments")]
        [ProducesResponseType(typeof(List<ListBookingPaymentResponseViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> ListReservationPayments(int reservation_id)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();
                var request = new RestRequest();
                request.AddParameter("reservation_id", reservation_id);

                var response = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<ListBookingPaymentResponseViewModel>>(request, PlanyoEndpoints.ListReservationPayment);
                if (response.ResponseCode == 0)
                {
                    result.Body = response.Data;
                    result.Message = response.ResponseMessage;

                    result.StatusCode = HttpStatusCode.OK;
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error while listing payment details for booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }



        /// <summary>
        ///List payments made for your reservations
        /// </summary>
        /// <returns>List payment details for bookings</returns>
        [HttpPost]
        [Route("/list_payments")]
        [ProducesResponseType(typeof(List<ListPaymentResponseViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> ListPayments([FromBody] ListPaymentViewModel payment)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();
                var request = new RestRequest();
                request.AddParameter("start_date", payment.Start_date);
                request.AddParameter("end_date", payment.End_date);
                
                var response = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<ListPaymentResponseViewModel>>(request, PlanyoEndpoints.ListPayment);
                if (response.ResponseCode == 0)
                {
                    result.Body = response.Data;
                    result.Message = response.ResponseMessage;

                    result.StatusCode = HttpStatusCode.OK;
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error while listing payment details for booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }
    }
}