﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace GCRieber.API
{
    public static class Program
    {
        private static IConfiguration _configuration;
        private static readonly string DotnetEnvironment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

        public static int Main(string[] args)
        {
            try
            {
                Log.Information("Application starting...");

                WebHost.CreateDefaultBuilder(args)
                    .ConfigureAppConfiguration((hostingContext, config) =>
                    {
                        ConfigureAppsettings(args, config);
                    })
                    .UseStartup<Startup>()
                    .UseApplicationInsights()
                    .UseSerilog()
                    .Build().Run();
                return 0;
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Application terminated unexpectedly");
                return 1;
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        private static void ConfigureAppsettings(string[] args, IConfigurationBuilder config)
        {
            var planyoInfo = new Dictionary<string, string>
            {
                {"Planyo:ApiKey", Environment.GetEnvironmentVariable("Planyo_ApiKey")},
                {"Planyo:Hashkey", Environment.GetEnvironmentVariable("Planyo_Hashkey")}
            };

            try
            {
                config.SetBasePath(Directory.GetCurrentDirectory());
                config.AddInMemoryCollection(planyoInfo);
                config.AddJsonFile("appsettings.json", false, true);
                config.AddJsonFile($"appsettings.{DotnetEnvironment}.json", true);
                config.AddEnvironmentVariables();
            }
            catch
            {
                // If the initialization causes the exception
                // "FileNotFoundException: The configuration file 'appsettings.json' was not found and is not optional."
                // it probably means your system has a Visual Studio installation from March 2018 or newer, in which case
                // the traditional meaning of GetCurrentDirectory is no longer valid, so we must make adjustments.
                config.SetBasePath(Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), @"../../../")));
                config.AddInMemoryCollection(planyoInfo);
                config.AddJsonFile("appsettings.json", false, true);
                config.AddJsonFile($"appsettings.{DotnetEnvironment}.json", true);
                config.AddEnvironmentVariables();
            }
        }


    }
}
