﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace GCRieber.API
{
    /// <summary>
    /// Class used to configure the repository classes
    /// </summary>
    public class DependencyInjection
    {
        internal void ConfigureRepositories(IServiceCollection services, IConfiguration configuration)
        {
            services.AddMvc();
        }
    }
}
