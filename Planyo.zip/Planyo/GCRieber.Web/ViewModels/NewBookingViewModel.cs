﻿using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Booking response model
    /// </summary>
    public class BookingResponseViewModel
    {
        /// <summary>
        /// Reservation ID of resource
        /// </summary>
        [JsonProperty("reservation_id")]
        public int ReservationId { get; set; }

        private ReservationStatus _status;
        /// <summary>
        /// Status of booking
        /// </summary>
        [JsonProperty("status")]
        public ReservationStatus Status
        {
            get { return _status; }
            set
            {
                // Set B to some new value
                _status = value;

                // Assign status text
                StatusText = value.GetDescription();
            }
        }

        /// <summary>
        /// Current status text
        /// </summary>
        public string StatusText { get; set; }

        /// <summary>
        /// Text to be displayed to user
        /// </summary>
        [JsonProperty("user_text")]
        public string UserText { get; set; }

        /// <summary>
        /// Resource Id
        /// </summary>
        [JsonProperty("resource_id")]
        public int ResourceId { get; set; }

        /// <summary>
        /// Currency
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Properties
        /// </summary>
        [JsonProperty("properties")]
        public BookingResponseProperties Properties { get; set; }

        /// <summary>
        /// Total price of booking
        /// </summary>
        [JsonProperty("total_price")]
        public string TotalPrice { get; set; }

        /// <summary>
        /// Original price of booking
        /// </summary>
        [JsonProperty("original_price")]
        public string OriginalPrice { get; set; }

        /// <summary>
        /// Discount
        /// </summary>
        [JsonProperty("discount")]
        public string Discount { get; set; }
    }

    /// <summary>
    /// Booking response properites
    /// </summary>
    public class BookingResponseProperties
    {
        /// <summary>
        /// Rental Tax Rate
        /// </summary>
        [JsonProperty("rental_tax_rate")]
        public int Rental_tax_rate { get; set; }
    }
}
