﻿using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Delete Reservation View Model
    /// </summary>
    public class DeleteBookingDataViewModel
    {
        private ReservationStatus _status;

        /// <summary>
        /// Status of reservation
        /// </summary>
        [JsonProperty("status")]
        public ReservationStatus Status
        {
            get { return _status; }
            set
            {
                // Set B to some new value
                _status = value;

                // Assign status text
                //StatusText = value.GetDescription();
            }
        }

        /// <summary>
        /// Current status text
        /// </summary>
        public string StatusText { get; set; }

        /// <summary>
        /// User Text
        /// </summary>
        [JsonProperty("user_text")]
        public string UserText { get; set; }
        
    }
}
