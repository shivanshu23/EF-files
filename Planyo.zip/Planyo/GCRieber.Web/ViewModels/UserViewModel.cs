﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Get user data view model
    /// </summary>
    public class GetUserDataViewModel
    {
        /// <summary>
        /// User ID
        /// </summary>
        [JsonProperty("id")]
        public int Id { get; set; }

        /// <summary>
        /// User Email
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// First name of user
        /// </summary>
        [JsonProperty("first_name")]
        public string First_name { get; set; }
    }

    /// <summary>
    /// Create new user data model
    /// </summary>
    public class CreateUserDataViewModel
    {
        /// <summary>
        /// Status of reservation
        /// </summary>
        [JsonProperty("user_id")]
        public int User_id { get; set; }

        /// <summary>
        /// Status of reservation
        /// </summary>
        [JsonProperty("is_new")]
        public int Is_new { get; set; }

    }
}

