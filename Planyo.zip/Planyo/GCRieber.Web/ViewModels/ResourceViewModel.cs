﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Resource data view model
    /// </summary>
    public class ResourceDataViewModel
    {
        /// <summary>
        /// Total number of resources
        /// </summary>
        [JsonProperty("resource_count")]
        public int ResourceCount { get; set; }

        /// <summary>
        /// Max pages
        /// </summary>
        [JsonProperty("max_page")]
        public int MaxPage { get; set; }

        /// <summary>
        /// Resources
        /// </summary>
        [JsonProperty("resources")]
        public Dictionary<string, ResourceItemViewModel> Resources { get; set; }
    }

    /// <summary>
    /// Single Resource item
    /// </summary>
    public class ResourceItemViewModel
    {
        /// <summary>
        /// Resource Name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Resource id
        /// </summary>
        [JsonProperty("id")]
        public int Id { get; set; }
    }
}
