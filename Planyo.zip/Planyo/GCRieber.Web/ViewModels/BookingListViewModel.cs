﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Booking List
    /// </summary>
    public class BookingListViewModel
    {
        /// <summary>
        /// Result property
        /// </summary>
        [JsonProperty("results")]
        public List<Booking> Results { get; set; } = new List<Booking>();
    }

    /// <summary>
    /// Result of the search
    /// </summary>
    public class Booking
    {
        /// <summary>
        /// Reservation ID of resource
        /// </summary>
        [JsonProperty("reservation_id")]
        public int ReservationId { get; set; }

        private ReservationStatus _status;
        /// <summary>
        /// Status of booking
        /// </summary>
        [JsonProperty("status")]
        public ReservationStatus Status
        {
            get { return _status; }
            set
            {
                // Set B to some new value
                _status = value;

                // Assign status text
                StatusText = value.GetDescription();
            }
        }

        /// <summary>
        /// Current status text
        /// </summary>
        public string StatusText { get; set; }

        /// <summary>
        /// Text to be displayed to user
        /// </summary>
        [JsonProperty("user_text")]
        public string UserText { get; set; }

        /// <summary>
        /// Quantity of resource
        /// </summary>
        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        /// <summary>
        /// Start time of booking
        /// </summary>
        [JsonProperty("start_time")]
        public string StartTime { get; set; }

        /// <summary>
        /// End time of booking
        /// </summary>
        [JsonProperty("end_time")]
        public string EndTime { get; set; }

        /// <summary>
        /// Currency of price
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// First name of customer
        /// </summary>
        [JsonProperty("first_name")]
        public string FirstName { get; set; }

        /// <summary>
        /// Last name of customer
        /// </summary>
        [JsonProperty("last_name")]
        public string LastName { get; set; }

        /// <summary>
        /// Email id of customer
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// Resource Id
        /// </summary>
        [JsonProperty("resource_id")]
        public int ResourceId { get; set; }

        /// <summary>
        /// Resource Name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Total price of booking
        /// </summary>
        [JsonProperty("total_price")]
        public string TotalPrice { get; set; }

        /// <summary>
        /// Original price of booking
        /// </summary>
        [JsonProperty("original_price")]
        public string OriginalPrice { get; set; }

        /// <summary>
        /// Properties of resource
        /// </summary>
        [JsonProperty("resource_properties")]
        public ResourceProperties Resource_properties { get; set; }

    }

    /// <summary>
    /// Resource properties description
    /// </summary>
    public class ResourceProperties
    {
        /// <summary>
        /// No of persons
        /// </summary>
        [JsonProperty("antall_personer")]
        public int Antall_personer { get; set; }

        /// <summary>
        /// Location of resource
        /// </summary>
        [JsonProperty("location")]
        public string Location { get; set; }

        /// <summary>
        /// Description about resource
        /// </summary>
        [JsonProperty("description")]
        public string Description { get; set; }

        /// <summary>
        /// Hidden flex admin duration
        /// </summary>
        [JsonProperty("hidden_flex_admin_duration")]
        public int Hidden_flex_admin_duration { get; set; }

        /// <summary>
        /// Hidden login required
        /// </summary>
        [JsonProperty("hidden_login_required")]
        public int Hidden_login_required { get; set; }
    }

    /// <summary>
    /// Booking view model
    /// </summary>
    public class BookingViewModel
    {
        /// <summary>
        /// Start Date and time
        /// </summary>
        public DateTime Start_Date { get; set; }

        /// <summary>
        /// End Date and time 
        /// </summary>
        public DateTime End_Date { get; set; }

        /// <summary>
        /// Quantity of Resource
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// First Name
        /// </summary>
        public string First_name { get; set; }

        /// <summary>
        /// Last Name
        /// </summary>
        public string Last_name { get; set; }

    }
}