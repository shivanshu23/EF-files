﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels.Authorization
{
    public class AuthorizationSettings
    {

        public bool Enabled { get; set; }
        public AzureB2CSettings AzureB2C { get; set; }
    }

    public class AzureB2CSettings
    {
        public string Tenant { get; set; }
        public string Audience { get; set; }
        public string Policy { get; set; }
    }
}
