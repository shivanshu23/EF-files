﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Add Booking payment details view model
    /// </summary>
    public class BookingPaymentViewModel
    {
        /// <summary>
        /// Reservation ID of resource
        /// </summary>
        public string ReservationId { get; set; }

        /// <summary>
        /// Mode of payment
        /// </summary>
        public string Payment_mode { get; set; }

        /// <summary>
        /// Payment status 
        /// </summary>
        public string Payment_status { get; set; }

        /// <summary>
        /// Payment response code 
        /// </summary>
        public string Payment_response_code { get; set; }

        /// <summary>
        /// Transaction id of payment  
        /// </summary>
        public string Transaction_id { get; set; }

        /// <summary>
        /// Transaction status text
        /// </summary>
        public string Transaction_status_text { get; set; }

        /// <summary>
        /// Amount paid
        /// </summary>
        public string Amount { get; set; }

        /// <summary>
        /// currency of payment
        /// </summary>
        public string Currency { get; set; }
    }

    /// <summary>
    /// Add Booking payment details response
    /// </summary>
    public class BookingPaymentResponseViewModel
    {
        /// <summary>
        /// Status
        /// </summary>
        [JsonProperty("status")]
        public int Status { get; set; }

        /// <summary>
        /// payment id
        /// </summary>
        [JsonProperty("payment_id")]
        public string Payment_id { get; set; }
    }

    /// <summary>
    /// Listing booking payment details response
    /// </summary>
    public class ListBookingPaymentResponseViewModel
    {
        /// <summary>
        /// Result property
        /// </summary>
        [JsonProperty("results")]
        public List<ListReservationPayment> Results { get; set; } = new List<ListReservationPayment>();
    }

    /// <summary>
    /// result response
    /// </summary>
    public class ListReservationPayment
    {
        /// <summary>
        /// Payment ID of resource
        /// </summary>
        [JsonProperty("payment_id")]
        public int Payment_id { get; set; }

        /// <summary>
        /// Amount of payment
        /// </summary>
        [JsonProperty("amount")]
        public double Amount { get; set; }

        /// <summary>
        /// Currency 
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Payment status
        /// </summary>
        [JsonProperty("payment_status")]
        public int Payment_status { get; set; }

        /// <summary>
        /// Time of payment
        /// </summary>
        [JsonProperty("payment_time")]
        public DateTime Payment_time { get; set; }

        /// <summary>
        /// Payment mode
        /// </summary>
        [JsonProperty("payment_mode")]
        public int Payment_mode { get; set; }

        /// <summary>
        /// Transaction id
        /// </summary>
        [JsonProperty("transaction_id")]
        public string Transaction_id { get; set; }

        /// <summary>
        /// Uid
        /// </summary>
        [JsonProperty("uid")]
        public int Uid { get; set; }
    }

    /// <summary>
    /// List Payment view model
    /// </summary>
    public class ListPaymentViewModel
    {
        /// <summary>
        /// Start date
        /// </summary>
        public DateTime Start_date { get; set; }

        /// <summary>
        /// End Date 
        /// </summary>
        public DateTime End_date { get; set; }
    }

    /// <summary>
    /// Listing payment response
    /// </summary>
    public class ListPaymentResponseViewModel
    {
        /// <summary>
        /// Result property
        /// </summary>
        [JsonProperty("results")]
        public List<ListPayment> Results { get; set; } = new List<ListPayment>();
    }

    /// <summary>
    /// Result response
    /// </summary>
    public class ListPayment
    {
        /// <summary>
        /// Payment Amount
        /// </summary>
        [JsonProperty("payment_amount")]
        public double Payment_amount { get; set; }

        /// <summary>
        /// Payment mode id
        /// </summary>
        [JsonProperty("payment_mode_id")]
        public int Payment_mode_id { get; set; }

        /// <summary>
        /// Payment id 
        /// </summary>
        [JsonProperty("payment_id")]
        public int Payment_id { get; set; }

        /// <summary>
        /// Date of Payment 
        /// </summary>
        [JsonProperty("payment_date")]
        public DateTime Payment_date { get; set; }

        /// <summary>
        /// Payment mode used
        /// </summary>
        [JsonProperty("payment_mode")]
        public string Payment_mode { get; set; }

        /// <summary>
        ///  ID of the payment in the payment gateway
        /// </summary>
        [JsonProperty("custom_id")]
        public string Custom_id { get; set; }

        /// <summary>
        /// Currency used 
        /// </summary>
        [JsonProperty("payment_currency")]
        public string Payment_currency { get; set; }

        /// <summary>
        /// Additional info about the payment
        /// </summary>
        [JsonProperty("payment_comment")]
        public string Payment_comment { get; set; }

        /// <summary>
        /// Status code of the payment 
        /// </summary>
        [JsonProperty("status_code")]
        public int Status_code { get; set; }

        /// <summary>
        /// Reservation ID for which the payment was made 
        /// </summary>
        [JsonProperty("reservation_id")]
        public int Reservation_id { get; set; }

        /// <summary>
        ///  ID of the reserved resource
        /// </summary>
        [JsonProperty("resource_id")]
        public int Resource_id { get; set; }

        /// <summary>
        /// User ID of the reservation
        /// </summary>
        [JsonProperty("user_id")]
        public int User_id { get; set; }

        /// <summary>
        /// Email id of customer
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// First name of customer 
        /// </summary>
        [JsonProperty("first_name")]
        public string First_name { get; set; }

        /// <summary>
        /// Last name  of customer 
        /// </summary>
        [JsonProperty("last_name")]
        public string Last_name { get; set; }

        /// <summary>
        /// Site id 
        /// </summary>
        [JsonProperty("site_id")]
        public int Site_id { get; set; }

        /// <summary>
        /// Status name
        /// </summary>
        [JsonProperty("status")]
        public string Status { get; set; }
    }
}