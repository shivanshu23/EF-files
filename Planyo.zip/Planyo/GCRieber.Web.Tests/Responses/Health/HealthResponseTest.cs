﻿namespace GCRieber.Web.Tests.Responses.Health
{
    public class HealthResponseTest
    {
        public int Operation { get; set; }
        public int Status { get; set; }
        public string Message { get; set; }
        public string Body { get; set; }
        public int StatusCode { get; set; }
    }
}
