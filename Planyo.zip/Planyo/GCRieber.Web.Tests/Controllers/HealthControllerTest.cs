﻿using System.Net.Http;
using System.Threading.Tasks;
using GCRieber.Web.Tests.Responses.Health;
using Newtonsoft.Json;
using Xunit;

namespace GCRieber.Web.Tests.Controllers
{
    public class HealthControllerTest : IClassFixture<HttpFixture>
    {
        private readonly HttpClient _client;

        public HealthControllerTest(HttpFixture httpFixture)
        {

            _client = httpFixture.GetClient();
        }

        [Fact]
        public async Task TestHealtReturnsOk() {

            var response = await _client.GetAsync("/api/health");

            // Assert that we are OK
            response.EnsureSuccessStatusCode();
        }


        //Test the response from the server.
        //Do not use the same class to hold the json as the server response
        // so that we test the contract and not the frameworks abbility to serialize json
        [Fact]
        public async Task TestHealtContractOnResponse()
        {

            var response = await _client.GetAsync("/api/health");
            var responseString = await response.Content.ReadAsStringAsync();

            var healthResponse = JsonConvert.DeserializeObject<HealthResponseTest>(responseString);

            Assert.Equal(2, healthResponse.Operation);
        }
    }
}
