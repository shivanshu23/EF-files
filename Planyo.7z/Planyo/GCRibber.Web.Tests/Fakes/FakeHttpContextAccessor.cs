﻿using Microsoft.AspNetCore.Http;

namespace GCRibber.Web.Tests.Fakes
{
    public class FakeHttpContextAccessor : IHttpContextAccessor
    {
        private HttpContext _httpContext;

        public HttpContext HttpContext
        {
            get => _httpContext??new DefaultHttpContext();
            set => _httpContext = value;
        }
    }
}