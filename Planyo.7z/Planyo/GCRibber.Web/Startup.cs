﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Swashbuckle.AspNetCore.Swagger;
using FluentValidation.AspNetCore;
using Microsoft.DotNet.PlatformAbstractions;
using Microsoft.EntityFrameworkCore;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace GCRibber.API
{
    public class Startup
    {
        private const string Swaggersecret = "fe9f6272-8a49-464c-96cf-d342bc9c1bab";
        private readonly Info _applicationInfo;
        private const string DefaultCorsPolicyName = "localhost";
        public IConfiguration Configuration { get; }
        public IHostingEnvironment Environment { get; }

        public Startup(IConfiguration configuration, IHostingEnvironment environment)
        {
            Configuration = configuration;
            Environment = environment;

            _applicationInfo = new Info();
            Configuration.GetSection("ApplicationInfo").Bind(_applicationInfo);
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc(setup =>
            {
                //...mvc setup...
            }).AddFluentValidation();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            new DependencyInjection().ConfigureRepositories(services, Configuration);

            ConfigureMonitoring(services);

            if (!Environment.IsProduction())
            {
                ConfigureSwagger(services);
            }

        }




        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors(DefaultCorsPolicyName); //Enable CORS!
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            //temporary simple authenticaion scheme to access swagger
            app.Use(async (context, next) => {

                if (context.Request.Path.StartsWithSegments("/api/swagger"))
                {
                    var ok = true;
                    var authHeader = context.Request.Headers["Authorization"].ToString();
                    if (authHeader != null
                        && authHeader.StartsWith("basic", StringComparison.OrdinalIgnoreCase)
                        && !(context.Request.Cookies["SWAGGERAUTH"] != null
                             && IsValid(context.Request.Cookies["SWAGGERAUTH"]))
                       )
                    {
                        var token = authHeader.Substring("Basic ".Length).Trim();
                        var credentialstring = Encoding.UTF8.GetString(Convert.FromBase64String(token));
                        var credentials = credentialstring.Split(':');
                        if (credentials[0] == "swg" && credentials[1] == "JMM?km=9XM!#,Lt!")
                        {
                            var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();
                            var hash = "";
                            using (var sha256 = System.Security.Cryptography.SHA256.Create())
                            {
                                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(now + Swaggersecret));
                                hash = BitConverter.ToString(hashedBytes);
                            }
                            string cookie = now + "|" + hash;
                            CookieOptions option = new CookieOptions();
                            option.Expires = DateTime.Now.AddMinutes(15);
                            context.Response.Cookies.Append("SWAGGERAUTH", cookie, option);
                            context.Response.Headers["Location"] = "/api/swagger";
                            context.Response.StatusCode = 302;
                            return;
                        }
                        else
                        {
                            ok = false;
                        }
                    }
                    else
                    {
                        ok = IsValid(context.Request.Cookies["SWAGGERAUTH"]);
                    }

                    if (!ok)
                    {
                        context.Response.StatusCode = 401;
                        context.Response.Headers.Add("WWW-Authenticate", "Basic realm=\"dotnetthoughts.net\"");
                        return;
                    }
                }
                await next.Invoke();
            });
            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger(c => {
                c.RouteTemplate = "api/swagger/{documentName}/swagger.json";
            });

            // Enable middleware to serve swagger-ui (HTML, JS, CSS etc.), specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/api/swagger/v1.0/swagger.json", "Versioned API v1.0");
                c.RoutePrefix = "api/swagger";
                c.DocExpansion(DocExpansion.None);
            });

            app.UseHsts();
            app.UseHttpsRedirection();
            app.UseMvc();

            //UpdateDatabase(app);
        }


        private void ConfigureSwagger(IServiceCollection services)
        {
            // Register the Swagger generator, defining one or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1.0", new Info { Title = "GCRibber API v1.0", Version = "v1.0" });

                c.AddSecurityDefinition("Bearer", new ApiKeyScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme. Example: \"Authorization: Bearer {token}\"",
                    Name = "Authorization",
                    In = "header",
                    Type = "apiKey"
                });

                // To enable token acceptance in authorization
                c.AddSecurityRequirement(new Dictionary<string, IEnumerable<string>>
                {
                    { "Bearer", new string[] { } }
                });

                // add documentation to Swagger api
                var basePath = ApplicationEnvironment.ApplicationBasePath.ToLower();
                c.IncludeXmlComments(Path.Combine(basePath, "GCRibber.API.xml"));

            });
        }

        private void ConfigureMonitoring(IServiceCollection services)
        {
            if (Configuration.GetSection("MonitoringEnabled").Get<bool>())
            {
                services.AddApplicationInsightsTelemetry(Configuration);
                // Enable K8s telemetry initializer for Application Insights
                services.EnableKubernetes();
            }
        }

        private bool IsValid(string cookie)
        {
            if (cookie == null || !cookie.Contains("|")) return false;
            bool retval = true;
            cookie = Uri.UnescapeDataString(cookie);
            var timestamp = cookie.Split("|")[0];
            var hash = cookie.Split("|")[1];

            var control = "";
            using (var sha256 = System.Security.Cryptography.SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(timestamp + Swaggersecret));
                control = BitConverter.ToString(hashedBytes);
            }


            var cookietime = DateTimeOffset.FromUnixTimeSeconds(long.Parse(timestamp));

            if (DateTimeOffset.UtcNow > cookietime.AddMinutes(15))
            {
                retval = false;
            }

            if (hash != control)
            {
                retval = false;
            }

            return retval;
        }

        /// <summary>
        /// Enables the automatic running of new migrations if any
        /// </summary>
        /// <param name="app">Specifies the object of the application</param>
        //private void UpdateDatabase(IApplicationBuilder app)
        //{
        //    using (var serviceScope = app.ApplicationServices
        //        .GetRequiredService<IServiceScopeFactory>()
        //        .CreateScope())
        //    {
        //        //DBContextName should be replaced with actual name of db context
        //        using (var context = serviceScope.ServiceProvider.GetService<DBContextName>())
        //        {
        //            context.Database.Migrate();
        //            context.SeedData();
        //        }
        //    }
        //}
    }
}
