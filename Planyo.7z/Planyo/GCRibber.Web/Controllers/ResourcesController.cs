﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using GCRibber.API.ViewModels;
using GCRibber.API.Helpers;
using GCRibber.API.Enums;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Configuration;
using RestSharp;

namespace GCRibber.API.Controllers
{
    /// <summary>
    /// Resource's endpoint
    /// </summary>
    [Route("api/resources")]
    [ApiController]
    public class ResourcesController : ControllerBase
    {
        private readonly ILogger _logger;
        readonly IConfiguration _configuration;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="configuration"></param>
        public ResourcesController(ILogger<ResourcesController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        /// <summary>
        /// Retrieves all the resources
        /// </summary>
        /// <returns>List of resources</returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<ResourceDataViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> Get()
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();
                var apiSetting = new PlanyoApiSetting(_configuration, "list_resources");
                var response = await apiSetting.ExecuteApiAsync<PlanyoResponseViewModel<ResourceDataViewModel>>(request);
                if (response.ResponseCode == 0)
                {
                    if (response.Data.Resources.Any())
                    {
                        result.Body = response.Data.Resources.Values;
                        result.Message = response.ResponseMessage;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error when trying to retrieve list of resources");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// Retrieves resource information
        /// </summary>
        /// <returns>List of available information about resource</returns>
        [HttpGet]
        [Route("{id}")]
        [ProducesResponseType(typeof(List<ResourceInfoDataViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> GetDetails(int id)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();
                request.AddParameter("resource_id", id);
                var apiSetting = new PlanyoApiSetting(_configuration, "get_resource_info");
                var response = await apiSetting.ExecuteApiAsync<PlanyoResponseViewModel<ResourceInfoDataViewModel>>(request);
                if (response.ResponseCode == 0)
                {
                    if (response.Data != null)
                    {
                        result.Body = response.Data;
                        result.Message = response.ResponseMessage;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error when trying to retrieve information about resource");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// New booking
        /// </summary>
        /// <returns>List of available information about resource</returns>
        [HttpPost]
        [Route("{resourceId}/bookings")]
        [ProducesResponseType(typeof(List<BookingDataViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> Bookings(int resourceId, [FromBody] BookingViewModel booking)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest(Method.GET);
                request.AddParameter("resource_id", resourceId);
                request.AddParameter("start_time", booking.Start_Date.ToString("yyyy-MM-dd HH:mm:ss"));
                request.AddParameter("end_time", booking.End_Date.ToString("yyyy-MM-dd HH:mm:ss"));
                request.AddParameter("quantity", booking.Quantity);
                request.AddParameter("email", booking.Email);
                request.AddParameter("first_name", booking.First_name);
                request.AddParameter("last_name", booking.Last_name);
                // check wheather user exist or not...
                var apiSetting = new PlanyoApiSetting(_configuration, "make_reservation");
                var response = await apiSetting.ExecuteApiAsync<PlanyoResponseViewModel<BookingDataViewModel>>(request);
                if (response.ResponseCode == 0)
                {
                    if (response.Data != null)
                    {
                        result.Body = response.Data;
                        result.Message = response.ResponseMessage;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// Modify User's Booking
        /// </summary>
        /// <returns>List of available information about resource</returns>
        [HttpPut]
        [Route("{resourceId}/bookings/{bookingid}")]
        [ProducesResponseType(typeof(List<ModifyBookingDataViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> ModifyBookings(int resourceId, int bookingid, [FromBody] ModifyBookingViewModel modifybooking)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();
                request.AddParameter("resource_id", resourceId);
                request.AddParameter("reservation_id", bookingid);
                request.AddParameter("start_time", modifybooking.Start_Date.ToString("yyyy-MM-dd HH:mm:ss"));
                request.AddParameter("end_time", modifybooking.End_Date.ToString("yyyy-MM-dd HH:mm:ss"));


                var apiSetting = new PlanyoApiSetting(_configuration, "modify_reservation");
                var response = await apiSetting.ExecuteApiAsync<PlanyoResponseViewModel<ModifyBookingDataViewModel>>(request);
                if (response.ResponseCode == 0)
                {
                    if (response.Data != null)
                    {
                        result.Body = response.Data;
                        result.Message = response.ResponseMessage;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while modifying booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// Search for a Resource to book
        /// </summary>
        /// <returns>List of available resources</returns>
        [HttpGet]
        [Route("/searchresource")]
        [ProducesResponseType(typeof(List<SearchResourceDataViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> SearchResource(DateTime start_time, DateTime end_time, string prop_res_gps_coords, string ppp_gps_coords_radius)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();
                int detail_level = 8; //need this parameter for fetching photos of resource.

                request.AddParameter("start_time", start_time.ToString("yyyy-MM-dd HH:mm:ss"));
                request.AddParameter("end_time", end_time.ToString("yyyy-MM-dd HH:mm:ss"));
                request.AddParameter("prop_res_gps_coords", prop_res_gps_coords);
                request.AddParameter("ppp_gps_coords_radius", ppp_gps_coords_radius);
                request.AddParameter("detail_level", detail_level);


                var apiSetting = new PlanyoApiSetting(_configuration, "resource_search");
                var response = await apiSetting.ExecuteApiAsync<PlanyoResponseViewModel<SearchResourceDataViewModel>>(request);
                if (response.ResponseCode == 0)
                {
                    if (response.Data != null)
                    {
                        result.Body = response.Data;
                        result.Message = response.ResponseMessage;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while searching for a resource");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// list_reservations
        /// </summary>
        /// <returns>List of available Reservation</returns>
        [HttpGet]
        [Route("/listreservation")]
        [ProducesResponseType(typeof(List<ListReservationDataViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> ListReservation(DateTime start_time, DateTime end_time, string email)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();

                request.AddParameter("start_time", start_time.ToString("yyyy-MM-dd HH:mm:ss"));
                request.AddParameter("end_time", end_time.ToString("yyyy-MM-dd HH:mm:ss"));
                request.AddParameter("user_email", email);

                var apiSetting = new PlanyoApiSetting(_configuration, "list_reservations");
                var response = await apiSetting.ExecuteApiAsync<PlanyoResponseViewModel<ListReservationDataViewModel>>(request);
                if (response.ResponseCode == 0)
                {
                    if (response.Data != null)
                    {
                        result.Body = response.Data;
                        result.Message = response.ResponseMessage;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while listing bookings of user");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// Delete Reservation
        /// </summary>
        /// <returns>Delete Reservation</returns>
        [HttpDelete]
        [Route("bookings/{bookingid}")]
        [ProducesResponseType(typeof(List<ListReservationDataViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> DeleteReservation(int bookingid)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();

                string action = "User_cancel";  //parameter for user cancelling the booking.
                request.AddParameter("reservation_id", bookingid);
                request.AddParameter("action", action);


                var apiSetting = new PlanyoApiSetting(_configuration, "do_reservation_action");
                var response = await apiSetting.ExecuteApiAsync<PlanyoResponseViewModel<DeleteBookingDataViewModel>>(request);
                if (response.ResponseCode == 0)
                {
                    if (response.Data != null)
                    {
                        result.Body = response.Data;
                        result.Message = response.ResponseMessage;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while deleting booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// Get User Data and Creates User if user doesn't exist
        /// </summary>
        /// <returns>User Data</returns>
        [HttpGet]
        [Route("/get-or-create-user")]
        [ProducesResponseType(typeof(List<ListReservationDataViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> GetOrCreateUser(string email, string First_name)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();
                request.AddParameter("email", email);

                var apiSetting = new PlanyoApiSetting(_configuration, "get_user_data");
                var response = await apiSetting.ExecuteApiAsync<PlanyoResponseViewModel<GetUserDataViewModel>>(request);

                if (response.ResponseCode != 0)   //user doesn't exist
                {
                    var request1 = new RestRequest(Method.GET);
                    request1.AddParameter("email", email);
                    request1.AddParameter("first_name", First_name);

                    var apiSetting1 = new PlanyoApiSetting(_configuration, "add_user");
                    var response1 = await apiSetting1.ExecuteApiAsync<PlanyoResponseViewModel<CreateUserDataViewModel>>(request1);
                    if (response1.ResponseCode == 0)
                    {
                        if (response1.Data != null)
                        {
                            result.Message = response1.ResponseMessage;
                            result.StatusCode = HttpStatusCode.OK;
                        }
                        return StatusCode((int)result.StatusCode, result);
                    }
                    
                    result.Status = Status.Fail;
                    result.Message = response1.ResponseMessage;
                    result.StatusCode = HttpStatusCode.BadRequest;
                    _logger.LogWarning(response1.ResponseMessage);
                    return StatusCode((int)HttpStatusCode.BadRequest, result);
                }

                if (response.ResponseCode == 0)
                {
                    if (response.Data != null)
                    {
                        result.Body = response.Data;
                        result.Message = response.ResponseMessage;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }

            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while deleting booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }


        /// <summary>
        /// Create new user
        /// </summary>
        /// <returns>Create new user</returns>
        [HttpPost]
        [Route("/createuser")]
        [ProducesResponseType(typeof(List<ListReservationDataViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> CreateUser([FromBody] CreateUserViewModel newuser)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();
                request.AddParameter("email", newuser.Email);
                request.AddParameter("first_name", newuser.First_name);

                var apiSetting = new PlanyoApiSetting(_configuration, "add_user");
                var response = await apiSetting.ExecuteApiAsync<PlanyoResponseViewModel<CreateUserDataViewModel>>(request);
                if (response.ResponseCode == 0)
                {
                    if (response.Data != null)
                    {
                        result.Message = response.ResponseMessage;
                        result.StatusCode = HttpStatusCode.OK;
                    }
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while creating new user");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }
    }
}