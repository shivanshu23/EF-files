﻿using GCRibber.API.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Hosting;
using System.Net;
using GCRibber.API.Enums;

namespace GCRibber.API.Controllers
{
    /// <summary>
    /// Diagnostic's endpoint
    /// </summary>
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class DiagnosticController : ControllerBase
    {
        private readonly IHostingEnvironment _environment;

        /// <summary>
        /// Controller
        /// </summary>
        /// <param name="environment"></param>
        public DiagnosticController(IHostingEnvironment environment)
        {
            _environment = environment;
        }

        /// <summary>
        /// For fetching details about the current environment
        /// </summary>
        /// <returns></returns>
        [HttpGet("environment")]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public ActionResult<IResult> Get()
        {
            var result = new Result { Status = Status.Success, Message = "GCRibber API is running in environment " + _environment.EnvironmentName, Body = _environment.EnvironmentName, Operation = Operation.Read, StatusCode = HttpStatusCode.OK };
            return Ok(result);
        }
    }
}
