﻿using System.Net;
using GCRibber.API.Enums;
using GCRibber.API.Helpers;
using Microsoft.AspNetCore.Mvc;

namespace GCRibber.API.Controllers
{
    /// <summary>
    /// Healthcheck enpoint should be useable as a health and liveness check
    /// </summary>
    [Produces("application/json")]
    [Route("api/Health")]
    public class HealthController : Controller
    {
        /// <summary>
        /// Returns the instance health
        /// </summary>
        /// <returns>Result model with status</returns>
        [HttpGet]
        public IResult Index()
        {
            return new Result { Status = Status.Success, Message = "GCRibber API is running", Body = "GCRibber API is running", Operation = Operation.Read, StatusCode = HttpStatusCode.OK};
        }
    }
}