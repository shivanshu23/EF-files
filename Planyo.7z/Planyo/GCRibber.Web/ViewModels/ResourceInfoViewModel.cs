﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRibber.API.ViewModels
{
    /// <summary>
    /// Resource data view model
    /// </summary>
    public class ResourceInfoDataViewModel
    {
        /// <summary>
        /// Resource name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Resource name translated to the language passed.
        /// </summary>
        [JsonProperty("translated_name")]
        public string Translated_name { get; set; }

        /// <summary>
        /// Number of units available
        /// </summary>
        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        /// <summary>
        /// Planyo site ID
        /// </summary>
        [JsonProperty("site_id")]
        public int Site_id { get; set; }

        /// <summary>
        /// Reservation approval mode
        /// </summary>
        [JsonProperty("confirmation_type")]
        public int Confirmation_type { get; set; }

        /// <summary>
        /// Category of the resource
        /// </summary>
        [JsonProperty("category")]
        public int Category { get; set; }

        /// <summary>
        /// Resource-specific properties 
        /// </summary>
        [JsonProperty("properties")]
        public Properties Properties { get; set; }

        /// <summary>
        /// Photos Array with photoId as key
        /// </summary>
        [JsonProperty("photos")]
        public Dictionary<string, Photo> Photos { get; set; }

        /// <summary>
        /// Base time unit of the resource
        /// </summary>
        [JsonProperty("time_unit")]
        public int Time_unit { get; set; }

        /// <summary>
        /// Resource's sharing mode
        /// </summary>
        [JsonProperty("sharing_mode")]
        public int Sharing_mode { get; set; }

        /// <summary>
        /// Resource is available on working days from this time
        /// </summary>
        [JsonProperty("start_hour")]
        public int Start_hour { get; set; }

        /// <summary>
        /// Resource is available on working days until this time 
        /// </summary>
        [JsonProperty("end_hour")]
        public int End_hour { get; set; }

        /// <summary>
        /// Allowed start quarters  
        /// </summary>
        [JsonProperty("start_quarters")]
        public int Start_quarters { get; set; }

        /// <summary>
        /// Price of one unit
        /// </summary>
        [JsonProperty("unit_price")]
        public string Unit_price { get; set; }

        /// <summary>
        /// Comma-seprated unit names
        /// </summary>
        [JsonProperty("unit_names")]
        public string Unit_names { get; set; }

        /// <summary>
        /// Currency in which prices are expressed
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// True for over-night rentals
        /// </summary>
        [JsonProperty("is_overnight_stay")]
        public bool? Is_overnight_stay { get; set; }

        /// <summary>
        /// Max. quantity allowed for a single reservation
        /// </summary>
        [JsonProperty("max_quantity_per_rental")]
        public int? Max_quantity_per_rental { get; set; }

        /// <summary>
        /// True for published resources
        /// </summary>
        [JsonProperty("is_published")]
        public bool Is_published { get; set; }

        /// <summary>
        /// Minimum rental time expressed in hours
        /// </summary>
        [JsonProperty("min_rental_time")]
        public float Min_rental_time { get; set; }

        /// <summary>
        /// Maximum rental time expressed in hours
        /// </summary>
        [JsonProperty("max_rental_time")]
        public float? Max_rental_time { get; set; }

        /// <summary>
        /// Resource setting Restrict starting times.
        /// </summary>
        [JsonProperty("start_times")]
        public string Start_times { get; set; }

        /// <summary>
        /// Resource setting Min. time between reservation and rental.
        /// </summary>
        [JsonProperty("min_hours_to_rental")]
        public int Min_hours_to_rental { get; set; }

        /// <summary>
        /// Resource setting Max. time between reservation and rental. 
        /// </summary>
        [JsonProperty("max_days_to_rental")]
        public int Max_days_to_rental { get; set; }

        /// <summary>
        /// Start dates or start dates and times for event-type resources
        /// </summary>
        [JsonProperty("event_dates")]
        public string Event_dates { get; set; }

        /// <summary>
        /// ID of the resource admin
        /// </summary>
        [JsonProperty("resource_admin_id")]
        public int? Resource_admin_id { get; set; }

        /// <summary>
        /// Name of the resource admin
        /// </summary>
        [JsonProperty("resource_admin_name")]
        public string Resource_admin_name { get; set; }

        /// <summary>
        /// Email address of the resource admin
        /// </summary>
        [JsonProperty("resource_admin_email")]
        public string Resource_admin_email { get; set; }

        /// <summary>
        /// Minimum time between consecutive rentals, expressed in hours
        /// </summary>
        [JsonProperty("min_time_between_rentals")]
        public float Min_time_between_rentals { get; set; }

        /// <summary>
        /// Pre-payment (deposit) amount. Value returned in %.
        /// </summary>
        [JsonProperty("prepayment_amount")]
        public string Prepayment_amount { get; set; }

        /// <summary>
        ///Max. number of hours before rental when the customer can pay the partial pre-payment (deposit) amount. 
        /// </summary>
        [JsonProperty("prepayment_amount_valid_until")]
        public int Prepayment_amount_valid_until { get; set; }

    }

    /// <summary>
    /// Information about image
    /// </summary>
    public class Photo
    {
        /// <summary>
        ///Image Id
        /// </summary>
        [JsonProperty("id")]
        public int Id { get; set; }

        /// <summary>
        ///Image path
        /// </summary>
        [JsonProperty("path")]
        public string Path { get; set; }

        /// <summary>
        ///Image title
        /// </summary>
        [JsonProperty("title")]
        public string Title { get; set; }

    }

    /// <summary>
    /// properties
    /// </summary>
    public class Properties
    {
        /// <summary>
        ///No. of persons
        /// </summary>
        [JsonProperty("number_of_persons")]
        public int Number_of_persons { get; set; }

        /// <summary>
        ///Description
        /// </summary>
        [JsonProperty("description")]
        public string Description { get; set; }

        /// <summary>
        ///GPS coordinates of Resource
        /// </summary>
        [JsonProperty("gps_coords")]
        public string Gps_coords { get; set; }

        /// <summary>
        ///Hidden flex admin duration
        /// </summary>
        [JsonProperty("hidden_flex_admin_duration")]
        public int Hidden_flex_admin_duration { get; set; }

        /// <summary>
        ///Hidden login required
        /// </summary>
        [JsonProperty("hidden_login_required")]
        public int Hidden_login_required { get; set; }

        /// <summary>
        ///xyz
        /// </summary>
        [JsonProperty("xyz")]
        public string Xyz { get; set; }
    }
}
