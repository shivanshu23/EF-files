﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRibber.API.ViewModels
{
    /// <summary>
    /// Get User data
    /// </summary>
    public class GetUserDataViewModel
    {
        /// <summary>
        /// User ID
        /// </summary>
        [JsonProperty("id")]
        public int Id { get; set; }

        /// <summary>
        /// User Email
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// First name of user
        /// </summary>
        [JsonProperty("first_name")]
        public string First_name { get; set; }
    }
}
