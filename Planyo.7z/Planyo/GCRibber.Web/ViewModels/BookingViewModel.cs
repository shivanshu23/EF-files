﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRibber.API.ViewModels
{
    /// <summary>
    /// Booking view model
    /// </summary>
    public class BookingViewModel
    {
        /// <summary>
        /// Start Date and time
        /// </summary>
        public DateTime Start_Date { get; set; }

        /// <summary>
        /// End Date and time 
        /// </summary>
        public DateTime End_Date{ get; set; }

        /// <summary>
        /// Quantity of Resource
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// Email
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// First Name
        /// </summary>
        public string First_name { get; set; }

        /// <summary>
        /// Last Name
        /// </summary>
        public string Last_name { get; set; }

    }

        /// <summary>
        /// Booking data view model
        /// </summary>
        public class BookingDataViewModel
    {
        /// <summary>
        /// Reservation id
        /// </summary>
        [JsonProperty("reservation_id")]
        public int Reservation_id { get; set; }

        /// <summary>
        /// Resource id
        /// </summary>
        [JsonProperty("resource_id")]
        public int Resource_id { get; set; }

        /// <summary>
        /// Total Price
        /// </summary>
        [JsonProperty("total_price ")]
        public float? Total_price { get; set; }

        /// <summary>
        /// Currency  
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Resource-specific properties 
        /// </summary>
        [JsonProperty("properties")]
        public BookingProperties Properties { get; set; }

    }

    /// <summary>
    /// properties
    /// </summary>
    public class BookingProperties
    {
        /// <summary>
        ///Rental Tax Rate
        /// </summary>
        [JsonProperty("rental_tax_rate")]
        public float Rental_tax_rate { get; set; }

        /// <summary>
        ///Total Price
        /// </summary>
        [JsonProperty("total_price")]
        public float Total_price { get; set; }

        /// <summary>
        ///Original Price
        /// </summary>
        [JsonProperty("original_price")]
        public float Original_price { get; set; }

        /// <summary>
        ///Discount
        /// </summary>
        [JsonProperty("discount")]
        public int Discount { get; set; }
        
    }
}
