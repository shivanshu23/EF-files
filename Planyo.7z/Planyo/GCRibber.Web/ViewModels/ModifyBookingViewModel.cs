﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRibber.API.ViewModels
{
    /// <summary>
    /// Modify booking view model
    /// </summary>
    public class ModifyBookingViewModel
    {
        /// <summary>
        /// Start Date and time
        /// </summary>
        public DateTime Start_Date { get; set; }

        /// <summary>
        /// End Date and time 
        /// </summary>
        public DateTime End_Date { get; set; }

    }

    /// <summary>
    /// Modify booking data 
    /// </summary>
    public class ModifyBookingDataViewModel
    {
        /// <summary>
        /// Warning Text
        /// </summary>
        [JsonProperty("warning_text")]
        public string Warning_text { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        [JsonProperty("status")]
        public int Status { get; set; }
    }
}
