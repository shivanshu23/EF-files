﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRibber.API.ViewModels
{
    /// <summary>
    /// Create user view model
    /// </summary>
    public class CreateUserViewModel
    {
        /// <summary>
        /// Email of user
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// First name of user
        /// </summary>
        public string First_name { get; set; }
    }

    /// <summary>
    /// Create new user data model
    /// </summary>
    public class CreateUserDataViewModel
    {
        /// <summary>
        /// Status of reservation
        /// </summary>
        [JsonProperty("user_id")]
        public int User_id { get; set; }

        /// <summary>
        /// Status of reservation
        /// </summary>
        [JsonProperty("is_new")]
        public int Is_new { get; set; }

    }
}
