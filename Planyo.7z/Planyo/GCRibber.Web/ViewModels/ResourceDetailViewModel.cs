﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRibber.API.ViewModels
{
    /// <summary>
    /// 
    /// </summary>
    public class ResourceDetailViewModel
    {
        /// <summary>
        /// Id of resource
        /// </summary>
        public string ResourceId { get; set; }
        /// <summary>
        /// Name of resource
        /// </summary>
        public string ResourceName { get; set; }
    }
}
