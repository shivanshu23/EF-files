﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRibber.API.ViewModels
{
    /// <summary>
    /// 
    /// </summary>
    public class SearchResourceDataViewModel
    {
        /// <summary>
        /// Result of search
        /// </summary>
        [JsonProperty("results")]
        public List<ResourceResult> Results { get; set; }
    }

    /// <summary>
    /// List of resources
    /// </summary>
    public class ResourceResult
    {
        /// <summary>
        /// Resource name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Number of units available
        /// </summary>
        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        /// <summary>
        /// Resource-specific properties 
        /// </summary>
        [JsonProperty("properties")]
        public ResourceProperties Properties { get; set; }

        /// <summary>
        /// Photos Array with photoId as key
        /// </summary>
        [JsonProperty("photos")]
        public Dictionary<string, ResourcePhoto> Photos { get; set; }

        /// <summary>
        /// Base time unit of the resource
        /// </summary>
        [JsonProperty("time_unit")]
        public int Time_unit { get; set; }

        /// <summary>
        /// Resource is available on working days from this time
        /// </summary>
        [JsonProperty("start_hour")]
        public int Start_hour { get; set; }

        /// <summary>
        /// Resource is available on working days until this time 
        /// </summary>
        [JsonProperty("end_hour")]
        public int End_hour { get; set; }

        /// <summary>
        /// Price of one unit
        /// </summary>
        [JsonProperty("unit_price")]
        public string Unit_price { get; set; }

        /// <summary>
        /// Currency in which prices are expressed
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }


    }

    /// <summary>
    /// Information about image
    /// </summary>
    public class ResourcePhoto
    {
        /// <summary>
        ///Image Id
        /// </summary>
        [JsonProperty("id")]
        public int Id { get; set; }

        /// <summary>
        ///Image path
        /// </summary>
        [JsonProperty("path")]
        public string Path { get; set; }

        /// <summary>
        ///Image title
        /// </summary>
        [JsonProperty("title")]
        public string Title { get; set; }

    }

    /// <summary>
    /// properties
    /// </summary>
    public class ResourceProperties
    {
        /// <summary>
        ///No. of persons
        /// </summary>
        [JsonProperty("number_of_persons")]
        public int Number_of_persons { get; set; }

        /// <summary>
        ///Description
        /// </summary>
        [JsonProperty("description")]
        public string Description { get; set; }

        /// <summary>
        ///GPS coordinates of Resource
        /// </summary>
        [JsonProperty("gps_coords")]
        public string Gps_coords { get; set; }

        /// <summary>
        ///Hidden flex admin duration
        /// </summary>
        [JsonProperty("hidden_flex_admin_duration")]
        public int Hidden_flex_admin_duration { get; set; }

        /// <summary>
        ///Hidden login required
        /// </summary>
        [JsonProperty("hidden_login_required")]
        public int Hidden_login_required { get; set; }

        /// <summary>
        ///xyz
        /// </summary>
        [JsonProperty("xyz")]
        public string Xyz { get; set; }
    }

}
