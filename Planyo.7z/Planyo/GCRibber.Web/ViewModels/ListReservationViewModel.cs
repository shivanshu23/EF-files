﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRibber.API.ViewModels
{
    /// <summary>
    /// 
    /// </summary>
    public class ListReservationDataViewModel
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("results")]
        public List<Results> Results { get; set; }
    }

    /// <summary>
    /// Result of the search
    /// </summary>
    public class Results
    {
        /// <summary>
        /// Reservation ID
        /// </summary>
        [JsonProperty("reservation_id")]
        public int Reservation_id { get; set; }

        /// <summary>
        /// Reservation ID
        /// </summary>
        [JsonProperty("status")]
        public int Status { get; set; }

        /// <summary>
        /// Reservation ID
        /// </summary>
        [JsonProperty("cart_id")]
        public int? Cart_id { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("creation_time")]
        public string Creation_time { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("quantity")]
        public int quantity { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("start_time")]
        public string Start_time { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("end_time")]
        public string End_time { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("first_name")]
        public string First_name { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("last_name")]
        public string Last_name { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("resource_id")]
        public int Resource_id { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }
    }
}
