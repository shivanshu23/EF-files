﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRibber.API.ViewModels
{
    /// <summary>
    /// Delete Reservation View Model
    /// </summary>
    public class DeleteBookingDataViewModel
    {
        /// <summary>
        /// Status of reservation
        /// </summary>
        [JsonProperty("status")]
        public int Status { get; set; }

        /// <summary>
        /// User Text
        /// </summary>
        [JsonProperty("user_text")]
        public string User_text { get; set; }
        
    }
}
