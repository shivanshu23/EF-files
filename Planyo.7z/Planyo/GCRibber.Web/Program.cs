﻿using System;
using System.IO;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Serilog;

namespace GCRibber.API
{
    public static class Program
    {
        private static IConfiguration _configuration;
        private static readonly string DotnetEnvironment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
        
        public static int Main(string[] args)
        {
            ConfigureAppsettings();
            ConfigureLogger();
            
            try 
            {
                Log.Information("Application starting...");
                
                WebHost.CreateDefaultBuilder(args)
                    .UseStartup<Startup>()
                    .UseApplicationInsights()
                    .UseSerilog()
                    .Build().Run();
                return 0;
            }
            catch(Exception ex)
            {
                Log.Fatal(ex, "Application terminated unexpectedly");
                return 1;
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        private static void ConfigureAppsettings()
        {
            try
            {
                _configuration =
                    new ConfigurationBuilder()
                        .SetBasePath(Directory.GetCurrentDirectory())
                        .AddJsonFile("appsettings.json", false, true)
                        .AddJsonFile($"appsettings.{DotnetEnvironment}.json", true)
                        .AddEnvironmentVariables()
                        .Build();
            }
            catch
            {
                // If the initialization causes the exception
                // "FileNotFoundException: The configuration file 'appsettings.json' was not found and is not optional."
                // it probably means your system has a Visual Studio installation from March 2018 or newer, in which case
                // the traditional meaning of GetCurrentDirectory is no longer valid, so we must make adjustments.
                _configuration =
                    new ConfigurationBuilder()
                        .SetBasePath(Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), @"../../../")))
                        .AddJsonFile("appsettings.json", false, true)
                        .AddJsonFile($"appsettings.{DotnetEnvironment}.json", true)
                        .AddEnvironmentVariables()
                        .Build();
            }
        }

        private static void ConfigureLogger()
        { 
          Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(_configuration)
                .Enrich.FromLogContext()
                .WriteTo.Console(outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss} [{Level:u3}] {RequestId} {RequestPath}: {Message:lj} {NewLine}{Exception}")
                .CreateLogger();
        }
    }
}
