﻿namespace GCRibber.API.Helpers
{

    public static class CommonErrorMessages
    {
        public const string UnknownError = "Sorry, we have encountered an error.";
        public const string BadRequest = "Invalid Request";
        public const string NoResultFound = "No Result Found";
        public const string SomethingWentWrong = "Some thing went wrong";
    }

    
}
