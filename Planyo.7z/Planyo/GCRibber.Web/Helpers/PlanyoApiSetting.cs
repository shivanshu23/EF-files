﻿using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using RestSharp;

namespace GCRibber.API.Helpers
{
    /// <summary>
    /// Planyo settings
    /// </summary>
    public class PlanyoApiSetting
    {
        #region Private properties

        /// <summary>
        /// Time stamp for planyo api
        /// </summary>
        private int UnixTimeStamp { get; }

        /// <summary>
        /// Hash string for 
        /// </summary>
        private string Md5Hash { get; }

        /// <summary>
        /// Method to access
        /// </summary>
        private string MethodName { get; }

        /// <summary>
        /// Planyo api base url
        /// </summary>
        private string ApiBaseUrL { get; }

        /// <summary>
        /// Planyo api key
        /// </summary>
        private string ApiKey { get; }

        /// <summary>
        /// Planyo api hash key
        /// it is to use only if hash is enabled
        /// </summary>
        private string ApiHashKey { get; }

        #endregion

        /// <summary>
        /// Initialize the planyo settings
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="methodName"></param>
        public PlanyoApiSetting(IConfiguration configuration, string methodName)
        {
            ApiKey = configuration["PlanyoApiKey"];
            ApiHashKey = configuration["PlanyoHashkey"];
            ApiBaseUrL = $"{configuration["PlanyoApiUrl"]}?method={methodName}";

            UnixTimeStamp = AppHelper.TimeStamp();
            MethodName = methodName;

            var hashToString = $"{ApiHashKey}{UnixTimeStamp}{MethodName}";
            Md5Hash = AppHelper.CreateHash(hashToString);
        }

        /// <summary>
        /// Execute api async
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="request"></param>
        /// <returns></returns>
        public Task<T> ExecuteApiAsync<T>(RestRequest request) where T : new()
        {
            var client = new RestClient(ApiBaseUrL);

            var taskCompletionSource = new TaskCompletionSource<T>();
            request.AddParameter("api_key", ApiKey);
            request.AddParameter("hash_timestamp", UnixTimeStamp);
            request.AddParameter("hash_key", Md5Hash);
            request.AddHeader("content-type", "application/json");
            client.ExecuteAsync<T>(request, (response) =>
            {
                if (response.ErrorException != null)
                    taskCompletionSource.TrySetException(response.ErrorException);
                else
                    taskCompletionSource.TrySetResult(response.Data);
                //taskCompletionSource.SetResult(response.Data)
            });
            return taskCompletionSource.Task;
        }
    }
}
