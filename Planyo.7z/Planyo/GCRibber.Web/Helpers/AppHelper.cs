﻿using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Http;

namespace GCRibber.API.Helpers
{
    /// <summary>
    /// Application helper methods
    /// </summary>
    public static class AppHelper
    {
        /// <summary>
        /// Split on all non-word characters.
        /// </summary>
        /// <param name="s"></param>
        /// <returns>Returns an array of all the words.</returns>
        public static string[] SplitWords(string s)
        {
            // @      special verbatim string syntax
            // \W+    one or more non-word characters together
            return Regex.Split(s, @"\W+");
        }

        /// <summary>
        /// Check string contains only alphabets
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static bool IsAlpha(string s)
        {
            var isAlpha = Regex.IsMatch(s, @"^[a-zA-Z]+$");
            return isAlpha;
        }

        /// <summary>
        /// String contains only numeric
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static bool IsNumeric(string s)
        {
            var isNumeric = Regex.IsMatch(s, @"^[0-9]+$");
            return isNumeric;
        }
        
        /// <summary>
        /// Attempt to lookup remote IP address by looking at the header X-Forwarded-For, then the HttpContextAccessor.
        /// </summary>
        /// <param name="request">HTTP request</param>
        /// <param name="accessor">HTTP context accessor</param>
        /// <param name="ipAddress">value to be set</param>
        /// <returns>IP address</returns>
        public static bool TryLookupRemoteIpAddress(HttpRequest request, IHttpContextAccessor accessor, out string ipAddress)
        {
            ipAddress = "";
            if (request?.Headers == null)
            {
                return false;
            }
            var xForwardedFor = request.Headers["X-Forwarded-For"].ToString();
            if (!string.IsNullOrEmpty(xForwardedFor))
            {
                ipAddress = xForwardedFor.Contains(",") ? xForwardedFor.Split(',')[0] : xForwardedFor;
                return true;
            }

            if (accessor?.HttpContext?.Connection?.RemoteIpAddress == null)
            {
                return false;
            }
            var remoteIpAddress = accessor.HttpContext.Connection.RemoteIpAddress.ToString();
            ipAddress = remoteIpAddress.Contains(",") ? remoteIpAddress.Split(',')[0] : remoteIpAddress;
            return true;
        }

        /// <summary>
        /// Time stamp for planyo api
        /// </summary>
        /// <returns></returns>
        public static int TimeStamp()
        {
            var unixTimeStamp = (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            return unixTimeStamp;
        }

        /// <summary>
        /// Create md5 hash
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string CreateHash(string input)
        {
            var hash = new StringBuilder();
            var md5Provider = new MD5CryptoServiceProvider();
            var bytes = md5Provider.ComputeHash(new UTF8Encoding().GetBytes(input));

            foreach (var t in bytes)
            {
                hash.Append(t.ToString("x2"));  //formats the string as 2 uppercase hexadecimal characters.
            }
            return hash.ToString();
        }
    }
}