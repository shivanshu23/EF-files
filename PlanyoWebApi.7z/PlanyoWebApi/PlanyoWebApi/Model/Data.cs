﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;


namespace PlanyoWebApi.Model
{
    public class ResponseModel
    {
        public Data Data { get; set; }
        public int Response_code { get; set; }
        public string Response_message { get; set; }
    }

    public class Data
    {
        public int Resource_count { get; set; }
        public int Max_page { get; set; }
        public Dictionary<string, ResourceDetail> Resources { get; set; }
    }

    public class ResourceDetail
    {
        public string Name { get; set; }
        public int Id { get; set; }
    }
}
