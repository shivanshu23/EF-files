﻿using System;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using RestSharp;
using Newtonsoft.Json;
using PlanyoWebApi.Helpers;

namespace PlanyoWebApi.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class PlanyoController : ControllerBase
    {
        string Key = "fc4c2238112f68a7a5efd6c11fed17f3dd5913cb07f1f9b05bd363d79add22";
        string Hashkey = "H62633eb4f05eec613436033d096e807de46043da40b833246fc0e77fcfd42f";
        
        /// <summary>
        /// List Resources
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetAllResources()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"list_resources"}";
            var md5Hash = Helper.CreateHash(concatString);

            int detail_level = 1;
            int page = 0;
            bool list_published_only = true;
            bool list_reservable_only = false;
            string list_resource_types = "all";
            //int admin_id = "";
            //string prop_res_xyz ="";
            //string ppp_gps_coords_radius ="";
            //string ppp_resfilter="";
            string sort = "site";
            int site_id = 46510;
            string language = "FR";
            
            var client = new RestClient("https://www.planyo.com/rest/?method=list_resources");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            
            request.AddParameter("detail_level", detail_level);
            request.AddParameter("page", page);
            request.AddParameter("start_time", list_published_only);
            request.AddParameter("list_reservable_only", list_reservable_only);
            request.AddParameter("list_resource_types", list_resource_types);
            request.AddParameter("sort", sort);
            request.AddParameter("site_id", site_id);
            request.AddParameter("language", language);


            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// GET Resource Information
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetResourceInfo()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"get_resource_info"}";
            var md5Hash = Helper.CreateHash(concatString);
            
            int resource_id = 137915;
            string language = "FR";

            var client = new RestClient("https://www.planyo.com/rest/?method=get_resource_info");
            var request = new RestRequest(Method.GET);

            request.AddHeader("content-type", "application/json");

            request.AddParameter("resource_id", resource_id);
            request.AddParameter("language", language);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Make New Reservation
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult MakeReservation()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"make_reservation"}";
            var md5Hash = Helper.CreateHash(concatString);

            int resource_id = 137915;
            DateTime start_time = new DateTime(2018, 11, 22);
            DateTime end_time = new DateTime(2018, 11, 25);
            int quantity = 2;
            bool admin_mode = true;
            bool send_notifications = true;
            //string force_status = "";
            int wants_share = 2;
            //string rental_prop_voucher = "";
            //string custom_price = "";
            //int user_id = ;
            string email = "kapilsharma@gmail.com";
            string first_name = "Kapil";
            string last_name = "Sharma";
            string address = "#768";
            string city = "Ambala";
            string zip = "134100";
            string state = "Haryana";
            string country = "India";
            string phone_prefix = "0172";
            string phone_number = "2547789";
            string mobile_prefix = "+91";
            string mobile_number = "9876543212";
            string user_notes = "I am User";
            string admin_notes = "I am Admin";
            //string refcode = "";
            DateTime creation_time = new DateTime(2018, 11, 21);
            //int cart_id = ;
            //string assignment1 = ""; 
            string language = "FR";


            var client = new RestClient("https://www.planyo.com/rest/?method=make_reservation");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("resource_id", resource_id);
            request.AddParameter("start_time", start_time);
            request.AddParameter("end_time", end_time);
            request.AddParameter("quantity", quantity);
            request.AddParameter("admin_mode", admin_mode);
            request.AddParameter("send_notifications", send_notifications);
            request.AddParameter("wants_share", wants_share);
            request.AddParameter("email", email);
            request.AddParameter("first_name", first_name);
            request.AddParameter("last_name", last_name);
            request.AddParameter("address", address);
            request.AddParameter("city", city);
            request.AddParameter("zip", zip);
            request.AddParameter("state", state);
            request.AddParameter("country", country);
            request.AddParameter("phone_prefix", phone_prefix);
            request.AddParameter("phone_number", phone_number);
            request.AddParameter("mobile_prefix", mobile_prefix);
            request.AddParameter("mobile_number", mobile_number);
            request.AddParameter("user_notes", user_notes);
            request.AddParameter("admin_notes", admin_notes);
            request.AddParameter("creation_time", creation_time);
            request.AddParameter("language", language);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// List Reservation
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult ListReservation()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"list_reservations"}";
            var md5Hash = Helper.CreateHash(concatString);

            DateTime start_time = new DateTime(2018, 11, 20);
            DateTime end_time = new DateTime(2018, 11, 30);
            int resource_id = 137796;
            int site_id = 46510;
            bool list_by_creation_date = false;
            string sort = "user_id";
            bool sort_reverse = false;
            int detail_level = 1;
            int user_id = 2932044;
            string user_email = "shivanshu@gmail.com";
            //string required_status = "";
            //string excluded_status = "";
            int page = 0;
            //DateTime modified_since = new DateTime(2018, 11, 12);
            string language = "FR";



            var client = new RestClient("https://www.planyo.com/rest/?method=list_reservations");
            var request = new RestRequest(Method.GET);

            request.AddHeader("content-type", "application/json");
            
            request.AddParameter("start_time", start_time);
            request.AddParameter("end_time", end_time);
            request.AddParameter("resource_id", resource_id);
            request.AddParameter("site_id", site_id);
            request.AddParameter("list_by_creation_date", list_by_creation_date);
            request.AddParameter("sort", sort);
            request.AddParameter("sort_reverse", sort_reverse);
            request.AddParameter("detail_level", detail_level);
            request.AddParameter("user_id", user_id);
            request.AddParameter("user_email", user_email);
            request.AddParameter("page", page);
            request.AddParameter("language", language);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Modify Reservation
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult ModifyReservation()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"modify_reservation"}";
            var md5Hash = Helper.CreateHash(concatString);

            int reservation_id = 5101879;
            //string reservation_ids = "";
            int resource_id = 137796;
            DateTime start_time = new DateTime(2018, 11, 25);
            DateTime end_time = new DateTime(2018, 11, 26);
            int user_id = 2932044;
            int quantity = 1;
            bool admin_mode = true;
            bool send_notifications = false;
            //string assignment1 = "";
            bool recalculate_price = true;
            string language = "FR";
            
            var client = new RestClient("https://www.planyo.com/rest/?method=modify_reservation");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");


            request.AddParameter("reservation_id", reservation_id);
            request.AddParameter("resource_id", resource_id);
            request.AddParameter("start_time", start_time);
            request.AddParameter("end_time", end_time);
            request.AddParameter("user_id", user_id);
            request.AddParameter("quantity", quantity);
            request.AddParameter("admin_mode", admin_mode);
            request.AddParameter("send_notifications", send_notifications);
            request.AddParameter("recalculate_price", recalculate_price);
            request.AddParameter("language", language);
            
            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }


        /// <summary>
        /// Confirm Reservation
        /// </summary>
        /// <params> resource_id, start_time, end_time, quantity</params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult ReservationAction()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"do_reservation_action"}";
            var md5Hash = Helper.CreateHash(concatString);

            int reservation_id = 5101879;
            //string reservation_ids = "";
            string action = "Cancel ";
            //string custom_data = "";
            string comment = "Booking Cancelled";
            bool is_quiet = false;
            string language = "FR";
            
            var client = new RestClient("https://www.planyo.com/rest/?method=do_reservation_action");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("reservation_id", reservation_id);
            request.AddParameter("action", action);
            request.AddParameter("comment", comment);
            request.AddParameter("is_quiet", is_quiet);
            request.AddParameter("language", language);
            
            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// GET Information for Site
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetSiteInfo()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"get_site_info"}";
            var md5Hash = Helper.CreateHash(concatString);
            int site_id = 46510;

            var client = new RestClient("https://www.planyo.com/rest/?method=get_site_info");
            var request = new RestRequest(Method.GET);

            request.AddHeader("content-type", "application/json");
            request.AddParameter("site_id", site_id);
            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        

        /// <summary>
        /// Returns Rental Price
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetRentalPrice()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"get_rental_price"}";
            var md5Hash = Helper.CreateHash(concatString);

            int resource_id = 137915;
            int site_id = 46510;
            DateTime start_time = new DateTime(2018, 11, 12);
            DateTime end_time = new DateTime(2018, 11, 16);
            int quantity = 1;
            bool admin_mode = true;

            var client = new RestClient("https://www.planyo.com/rest/?method=get_rental_price");
            var request = new RestRequest(Method.GET);

            request.AddHeader("content-type", "application/json");
            request.AddParameter("site_id", site_id);
            request.AddParameter("resource_id", resource_id);
            request.AddParameter("start_time", start_time);
            request.AddParameter("end_time", end_time);
            request.AddParameter("quantity", quantity);
            request.AddParameter("admin_mode", admin_mode);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        

        


        /// <summary>
        /// Can Make Reservation
        /// </summary>
        /// <params> resource_id, start_time, end_time, quantity</params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult CanMakeReservation()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"can_make_reservation"}";
            var md5Hash = Helper.CreateHash(concatString);

            int resource_id = 137796;
            int site_id = 46510;
            DateTime start_time = new DateTime(2018, 11, 25);
            DateTime end_time = new DateTime(2018, 11, 27);
            int quantity = 1;


            var client = new RestClient("https://www.planyo.com/rest/?method=can_make_reservation");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("site_id", site_id);
            request.AddParameter("resource_id", resource_id);
            request.AddParameter("start_time", start_time);
            request.AddParameter("end_time", end_time);
            request.AddParameter("quantity", quantity);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        

        /// <summary>
        /// Add new Resource
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult AddResource()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"add_resource"}";
            var md5Hash = Helper.CreateHash(concatString);

            addResource data = new addResource
            {
                base_resource_id = 137915,
                name = "Wedding-Hall 2",
                quantity = 1

            };
            var jsonString = JsonConvert.SerializeObject(data);


            //int base_resource_id = 137796;
            //string name = "Super-Deluxe";
            //int site_id = 46510;
            //int quantity = 5;
            //float min_rental_time = 10.0F;
            //int min_hours_to_rental = 12;
            //int max_days_to_rental = 20;
            //string default_price = "4000";

            var client = new RestClient("https://www.planyo.com/rest/?method=add_resource");
            var request = new RestRequest(Method.GET);
            //request.AddHeader("content-type", "application/json");

            request.AddHeader("Accept", "application/json");


            request.AddParameter("application/json", jsonString);



            // request.AddParameter("site_id", jsonString);
            //request.AddParameter("base_resource_id", base_resource_id);
            //request.AddParameter("name", name);
            //request.AddParameter("quantity", quantity);
            //request.AddParameter("min_rental_time", min_rental_time);
            //request.AddParameter("min_hours_to_rental", min_hours_to_rental);
            //request.AddParameter("max_days_to_rental", max_days_to_rental);
            //request.AddParameter("default_price", default_price);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Modify Resource
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult ModifyResource()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"modify_resource"}";
            var md5Hash = Helper.CreateHash(concatString);

            int resource_id = 137915;
            string name = "Deluxe";
            int quantity = 5;
            float min_rental_time = 6.0F;
            float min_hours_to_rental = 12.0F;
            int max_days_to_rental = 20;
            string default_price = "2000";
            int default_price_type = 7;

            var client = new RestClient("https://www.planyo.com/rest/?method=modify_resource");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("resource_id", resource_id);
            request.AddParameter("name", name);
            request.AddParameter("quantity", quantity);
            request.AddParameter("min_rental_time", min_rental_time);
            request.AddParameter("min_hours_to_rental", min_hours_to_rental);
            request.AddParameter("max_days_to_rental", max_days_to_rental);
            request.AddParameter("default_price", default_price);
            request.AddParameter("default_price_type", default_price_type);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Remove a Resource
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult RemoveResource()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"remove_resource"}";
            var md5Hash = Helper.CreateHash(concatString);

            int resource_id = 138025;
            string resource_name = "Super-Deluxe";
            int parent_site_id = 46510;
            string resource_id_toString = resource_id.ToString();
            var resource_id_md5 = Helper.CreateHash(resource_id_toString);

            var client = new RestClient("https://www.planyo.com/rest/?method=remove_resource");
            var request = new RestRequest(Method.DELETE);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("resource_id", resource_id);
            request.AddParameter("resource_name", resource_name);
            request.AddParameter("parent_site_id", parent_site_id);
            request.AddParameter("resource_id_md5", resource_id_md5);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }


        ///// <summary>
        ///// Add New Product
        ///// </summary>
        ///// <params></params>
        ///// <returns></returns>
        //[HttpGet]
        //public IActionResult AddNewProduct()
        //{
        //    Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
        //    string concatString = $"{hashkey}{unixTimeStamp}{"add_additional_product"}";
        //    var md5Hash = Helper.CreateHash(concatString);

        //    int site_id = 46510;
        //    string name = "Lunch Buffet";
        //    float price = 1000.0F;
        //    int max_quantity = 3;
        //    String description = "Lunch Buffet Available from 12pm to 3pm";
        //    float tax_rate = 18.5F;
        //    bool is_recurring = true;

        //    var client = new RestClient("https://www.planyo.com/rest/?method=add_additional_product");
        //    var request = new RestRequest(Method.GET);
        //    request.AddHeader("content-type", "application/json");

        //    request.AddParameter("site_id", site_id);
        //    request.AddParameter("name", name);
        //    request.AddParameter("price", price);
        //    request.AddParameter("max_quantity", max_quantity);
        //    request.AddParameter("description", description);
        //    request.AddParameter("is_recurring", is_recurring);
        //    request.AddParameter("tax_rate", tax_rate);

        //    request.AddParameter("api_key", key);
        //    request.AddParameter("hash_timestamp", unixTimeStamp);
        //    request.AddParameter("hash_key", md5Hash);

        //    IRestResponse response = client.Execute(request);
        //    return Ok(response.Content);
        //}

        /// <summary>
        /// Add New Product
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult AddNewProduct()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"add_additional_product"}";
            var md5Hash = Helper.CreateHash(concatString);

            addProduct data = new addProduct
            {
                name = "Parking",
                price = 1000.0F,
                max_quantity = 1

            };

            var request = new RestRequest(Method.GET);
            //string jsonString = JsonConvert.SerializeObject(data);
            var json = request.JsonSerializer.Serialize(data);

            var client = new RestClient("https://www.planyo.com/rest/?method=add_additional_product");

            //request.AddHeader("content-type", "application/json");

            //request.RequestFormat = DataFormat.Json;
            request.AddParameter("application/json; charset=utf-8","{\"name\":\"Parking\",\"price\":1000,\"max_quantity\":1}" , ParameterType.RequestBody);


            //request.AddParameter("application/json", json, ParameterType.RequestBody);
            
            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Add Product Image
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult AddProductImage()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"add_product_image"}";
            var md5Hash = Helper.CreateHash(concatString);

            int product_id = 15027;
            string image_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Breakfast_Buffet_%2821720094978%29.jpg/1200px-Breakfast_Buffet_%2821720094978%29.jpg";
            string title = "Lunch buffet";

            var client = new RestClient("https://www.planyo.com/rest/?method=add_product_image");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("product_id", product_id);
            request.AddParameter("image_url", image_url);
            request.AddParameter("title", title);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Set Payment Gateway
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult SetPaymentGateway()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"set_payment_gateway"}";
            var md5Hash = Helper.CreateHash(concatString);

            int payment_mode = 1;
            string account_id = "shivanshu.ojas@gmail.com";

            var client = new RestClient("https://www.planyo.com/rest/?method=set_payment_gateway");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("payment_mode", payment_mode);
            request.AddParameter("account_id", account_id);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Add New User
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult AddUser()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"add_user"}";
            var md5Hash = Helper.CreateHash(concatString);

            string email = "sham@gmail.com";
            string first_name = "ram";
            //string user_login = "ramram";
            //string user_password = "shivanshu2394";
            //string country = "INDIA";

            var client = new RestClient("https://www.planyo.com/rest/?method=add_user");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("email", email);
            request.AddParameter("first_name", first_name);
            //request.AddParameter("user_login", user_login);
            //request.AddParameter("user_password", user_password);
            //request.AddParameter("country", country);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Get User Data
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetUserData()
        {
            getuserdata data = new getuserdata { user_id = 2925936 };
            var jsonString = JsonConvert.SerializeObject(data);

            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"get_user_data"}";
            var md5Hash = Helper.CreateHash(concatString);

            var client = new RestClient("https://www.planyo.com/rest/?method=get_user_data");
            var request = new RestRequest(Method.GET);

            request.AddHeader("Accept", "application/json");
            request.Parameters.Clear();

            //request.AddParameter("user_id", jsonString, ParameterType.RequestBody);

            request.AddParameter("user_id", jsonString);
            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);
            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Remove User
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult RemoveUser()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"remove_user"}";
            var md5Hash = Helper.CreateHash(concatString);

            int user_id = 123456789;

            var client = new RestClient("https://www.planyo.com/rest/?method=remove_user");
            var request = new RestRequest(Method.DELETE);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("user_id", user_id);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Send Email to Customer
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult SendEmailToCustomer()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"send_email_to_customer"}";
            var md5Hash = Helper.CreateHash(concatString);

            int reservation_id = 5101879;
            string message_title = "Booking Details";
            string message_content = "Thanks for Booking with us. Have a wonderful stay";
            string language = "FR";

            var client = new RestClient("https://www.planyo.com/rest/?method=send_email_to_customer");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("reservation_id", reservation_id);
            request.AddParameter("message_title", message_title);
            request.AddParameter("message_content", message_content);
            request.AddParameter("language", language);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Generate Invoice
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GenerateInvoice()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"generate_invoice"}";
            var md5Hash = Helper.CreateHash(concatString);

            int reservation_id = 5102232;
            string language = "FR";

            var client = new RestClient("https://www.planyo.com/rest/?method=generate_invoice");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("reservation_id", reservation_id);
            request.AddParameter("language", language);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// Get Invoice Item
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult GetInvoiceItem()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"get_invoice_items"}";
            var md5Hash = Helper.CreateHash(concatString);

            int reservation_id = 5101879;
            string language = "FR";

            var client = new RestClient("https://www.planyo.com/rest/?method=get_invoice_items");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("reservation_id", reservation_id);
            request.AddParameter("language", language);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }

        /// <summary>
        /// List Invoice
        /// </summary>
        /// <params></params>
        /// <returns></returns>
        [HttpGet]
        public IActionResult ListInvoice()
        {
            Int32 unixTimeStamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            string concatString = $"{Hashkey}{unixTimeStamp}{"list_invoices"}";
            var md5Hash = Helper.CreateHash(concatString);

            int reservation_id = 5101879;
            string language = "FR";

            var client = new RestClient("https://www.planyo.com/rest/?method=list_invoices");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");

            request.AddParameter("reservation_id", reservation_id);
            request.AddParameter("language", language);

            request.AddParameter("api_key", Key);
            request.AddParameter("hash_timestamp", unixTimeStamp);
            request.AddParameter("hash_key", md5Hash);

            IRestResponse response = client.Execute(request);
            return Ok(response.Content);
        }  
    }
    public class getuserdata
    {
        public int user_id { get; set; }
    }

    public class addResource
    {
        public int base_resource_id { get; set; }
        public string name { get; set; }
        public int quantity { get; set; }

    }

    public class addProduct
    {
        public string name { get; set; }
        public float price { set; get; }
        public int max_quantity { get; set; }
    }
}
