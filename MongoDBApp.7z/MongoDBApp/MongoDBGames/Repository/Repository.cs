﻿using MongoDB.Driver;
using MongoDBGames.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
namespace MongoDBGames.Repository
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private readonly ApplicationContext _context;
        private string collection;

        public Repository(ApplicationContext context, string collectionName)
        {
            collection = collectionName;
            _context = context;
        }
        public IMongoCollection<T> Collection => _context._db.GetCollection<T>(collection);


        public IEnumerable<T> GetAll()
        {
            return Collection.AsQueryable();
        }

        public T GetByName(Expression<Func<T, bool>> expression)
        {
            return Collection.Find(expression).FirstOrDefault();
        }      

        public void Create(T item)
        {
            Collection.InsertOne(item);           
        }

        public T Update(Expression<Func<T, bool>> expression, UpdateDefinition<T> update)
        {
            return Collection.FindOneAndUpdate(expression, update);
        }

        public T Delete(Expression<Func<T, bool>> expression)
        {
            return Collection.FindOneAndDelete(expression);
        }
    }
}
