﻿using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDBGames.Model;

namespace MongoDBGames.Repository
{
    public class ItemRepository : Repository<Items>, IItemRepository
    {
       private readonly ApplicationContext _context;

        public ItemRepository(ApplicationContext context) : base(context, "Items")
        {
            _context = context;
        }

        public IEnumerable<Items> GetAllItems()
        {
            var data= GetAll();

            var obj = new ItemsViewModel();

            List<string> ls = new List<string>();
            
            foreach(var i in data)
            {
                ls.Add(i.Id.ToString());
                ls.Add(i.ItemName);
                ls.Add(i.Price.ToString());
                ls.Add(i.QuantityAvailable.ToString());
            }

            return ls;
        }

        public Items GetItemById(ObjectId itemId)
        {
            return GetByName(x=>x.Id == itemId);
        }      

        public void CreateItem(Items item)
        {
             Create(item);
        }

        public Items UpdateItem(ObjectId id, Items item)
        {
            var updateDefinition = Builders<Items>.Update
                   .Set(x => x.Id, item.Id)
                   .Set(x => x.ItemName, item.ItemName)
                   .Set(x => x.Price, item.Price)
                   .Set(x => x.QuantityAvailable, item.QuantityAvailable);


            return Update(x => x.Id == id, updateDefinition);
        }

        public Items DeleteItem(ObjectId id)
        {
            return Delete(x => x.Id == id);
        }
    }
}