﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

namespace MongoDBGames.Model
{
    public class Customer
    {
        [BsonId]
        public ObjectId Id { get; set; }

        [BsonElement("customerId")]
        public int CustomerID { get; set; }

        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("country")]
        public string Country { get; set; }

        [BsonElement("orders")]
        public List<Order>  Orders { get; set; }
    }

    public class Order
    {
        [BsonId]
        public ObjectId OrderId { get; set; }

        [BsonElement("itemId")]
        public List<ObjectId> ItemId { get; set; }

        [BsonElement("price")]
        public double Price { get; set; }

        [BsonElement("orderDate")]
        public DateTime OrderDate { get; set; }
    }  
}
