﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MongoDBGames.Model
{
    public class ItemsViewModel
    {
        public string Id { get; set; }

        public string ItemName { get; set; }

        public int Price { get; set; }

        public int QuantityAvailable { get; set; }
    }
}
