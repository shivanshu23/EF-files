import { Component, OnInit } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';
import { formatDate } from '@angular/common';
import { format } from 'url';
import { forEach } from '@angular/router/src/utils/collection';
import { map, filter } from 'rxjs/operators';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-my-bookings',
  templateUrl: './my-bookings.component.html',
  styleUrls: ['./my-bookings.component.css']
})
export class MyBookingsComponent implements OnInit {
  bookingList: any;
  startDate: any;
  endDate: any;
  jsonDate: any;
  currentDate: any;
  onGoing: any;
  upComing: any;
  onGoingBooking: any;
  upComingBooking: any;

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.ListBookings();
  }

  ListBookings() {
    this.currentDate = new Date();
    this.jsonDate = new Date().toJSON().slice(0, 10);

    this.startDate = formatDate(new Date(), 'yyyy/MM/dd HH:mm', 'en');
    this.endDate = formatDate(this.currentDate.setDate(this.currentDate.getDate() + 30), 'yyyy/MM/dd HH:mm', 'en');

    let params = new HttpParams().set("StartDateTime", this.startDate).set("EndDateTime", this.endDate).set("user_email", JSON.parse(localStorage.getItem('User Email'))).set("detail_level", '4');
    this.http.get("http://localhost:39521/api/bookings", { params: params })
      .subscribe((data: any) => {
        const res = { ongoing: [], upcoming: [] };
        this.onGoingBooking = res.ongoing.push(data.body.filter(item => item.start_time.slice(0, 10) === this.jsonDate));

        let difference = data.body.filter(item => !res.ongoing[0].includes(item));
        res.upcoming.push(difference);

        this.bookingList = data;
        this.onGoingBooking = res.ongoing;
        this.upComingBooking = res.upcoming;
      });
  }
}
