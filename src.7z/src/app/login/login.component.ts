import { Component, OnInit } from '@angular/core';
import { User } from '../Classes/User';
import { LoginService } from '../Services/login.service';
import { Router } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  username: string;
  password: string;
  submitted = false;

  constructor(
    private router: Router,
    private loginService: LoginService,
    private toastr: ToastrService) { }


  ngOnInit() {
    const token = localStorage.getItem('token');
    if (!isNullOrUndefined(token)) {
      localStorage.removeItem('token');
    }
  }

  user: User;
  authenticationFlag: boolean = true;
  errorMessage: string = '';


  onSubmit() {

    this.submitted = true;

    this.loginService.login(this.username, this.password)
      .subscribe((result: any) => {
        if (result.token != null) {
          localStorage.setItem('Token', JSON.stringify((result.token)));
          localStorage.setItem('User ID', JSON.stringify(result.userId));
          localStorage.setItem('First Name', JSON.stringify(result.firstName));
          localStorage.setItem('Last Name', JSON.stringify(result.lastName));
          localStorage.setItem('User Email', JSON.stringify(result.mail));

          this.toastr.success('Logged in','',{ timeOut: 1000});
          this.router.navigate(['dashboard']);
        }
      },
        error => {
          debugger;
          console.log(error);
          this.authenticationFlag = false;
        });
  }
}

