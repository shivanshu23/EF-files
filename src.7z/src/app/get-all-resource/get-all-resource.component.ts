import { Component, OnInit, Input } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BookingViewModel } from '../Model/BookingModel';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import 'rxjs/add/operator/catch';

@Component({
  selector: 'app-get-all-resource',
  templateUrl: './get-all-resource.component.html',
  styleUrls: ['./get-all-resource.component.css']
})
export class GetAllResourceComponent implements OnInit {

  constructor(private http: HttpClient,
    private router: Router,
    private toastr: ToastrService) { }
  resourceList: any;
  bookingInfo: any;
  result: any;
  val: any;

  ngOnInit() { }

  getAllResources(form: any) {

    let params = new HttpParams().set("StartDateTime", form.startDate).set("EndDateTime", form.endDate).set("Location", form.location);

    this.http.get("http://localhost:39521/api/resources", { params: params })
      .subscribe(
        (data) => {
          this.resourceList = data as string[];

          this.toastr.success('List of Resources', '', { timeOut: 700 });

          console.log(this.resourceList.body);
        }
      )
  }

  imageInfo(id: any) {
    this.val = id;

    console.log(id);
  }

  error: any = { isError: false, errorMessage: '' };

  bookingViewModel: BookingViewModel

  BookResource(res: any, formValue: any) {
    const resourceObj: BookingViewModel = {
      startDate: formValue.startDate,
      endDate: formValue.endDate,
      firstName: JSON.parse(localStorage.getItem('First Name')),
      lastName: JSON.parse(localStorage.getItem('Last Name')),
      quantity: 1,
      token: 'cus_EU7g4sIAqP46az',
      email: JSON.parse(localStorage.getItem('User Email'))
    };

    this.http.post("http://localhost:39521/api/bookings/" + res.id, resourceObj)
      .subscribe(
        data => {
          this.bookingInfo = data as string[];
          this.result = this.bookingInfo.body;
          if (this.result) {
            this.toastr.success('Booking Successfull', '', { timeOut: 5000 });
          }
          else {
            this.toastr.success(this.bookingInfo.message, '', { timeOut: 7000 });
            this.router.navigate(['resource']);
          }
        });
  }
}