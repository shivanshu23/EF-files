import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'] 
})
export class DashboardComponent implements OnInit {

  constructor(private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit() { }

  public checkToken() {
    const token = localStorage.getItem('Token');
    if (!token) {
      return false;
    }
    return true;
  }

  public logout() {
    localStorage.removeItem('Token');
    localStorage.removeItem('User Email');
    localStorage.removeItem('User ID');
    localStorage.removeItem('User Name');

    this.toastr.success('Logout', '', { timeOut: 2000 });
  }

  public dashboard() {
    this.router.navigate(['dashboard']);
  }
  public createBooking() {
    const link = ['/dashboard/resource'];
    this.router.navigate(link);
  }
  public myBookings() {
    const link = ['/dashboard/bookings'];
    this.router.navigate(link);
  }
}
