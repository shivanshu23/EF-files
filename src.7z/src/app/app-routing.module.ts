import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthService } from '../app/_helpers/AuthService';
import { DashboardComponent } from '../app/dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { GetAllResourceComponent } from './get-all-resource/get-all-resource.component';
import { GetResourceDeatilsComponent } from './get-resource-deatils/get-resource-deatils.component';
import { MyBookingsComponent } from '../app/my-bookings/my-bookings.component';
import { BookingDetailComponent } from './booking-detail/booking-detail.component';


const appRoutes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  {
    path: 'dashboard', component: DashboardComponent, canActivate: [AuthService],
    children: [{
      path: 'resource',
      component: GetAllResourceComponent,
      canActivateChild: [AuthService]
    },
    {
      path: 'resourceDetails/:id',
      component: GetResourceDeatilsComponent,
      canActivateChild: [AuthService]
    },
    {
      path: 'bookings',
      component: MyBookingsComponent,
      canActivateChild: [AuthService]
    },
    {
      path: 'booking/:id',
      component: BookingDetailComponent,
      canActivateChild: [AuthService]
    }
    ]
  },

];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
