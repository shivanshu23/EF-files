import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Params, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-booking-detail',
  templateUrl: './booking-detail.component.html',
  styleUrls: ['./booking-detail.component.css']
})
export class BookingDetailComponent implements OnInit {
  id: any;
  info: any;
  noData : any;

  constructor(private http: HttpClient, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params: Params) => {
        this.id = params["id"];
        if (this.id !== null && this.id !== '') {
          this.bookingInfo();
        }
      });
  }

  bookingInfo() {
   
    this.http.get("http://localhost:39521/api/bookings/" + this.id)
      .subscribe(
        (data: any) => {
          if(data.status == 1)
          {
            this.info = data.body;
            console.log(this.info);
          }
          else{
           this.noData= "No Data found";
          }
          
        })
  }
}
