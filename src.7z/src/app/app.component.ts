import { Component } from '@angular/core';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private toastr: ToastrService) { }

  title = 'Planyo Reservation System';

  public checkToken()
    {
        const token = localStorage.getItem('Token');
        if(!token){
            return false;
        }
        return true;
    }
    
    public logout()
    {
      debugger;
      localStorage.removeItem('Token');
      localStorage.removeItem('User Email');
      localStorage.removeItem('User ID');
      localStorage.removeItem('User Name');

      this.toastr.success('Logout','',{ timeOut: 2000});
    }
}
