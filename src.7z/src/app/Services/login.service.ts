import { Observable } from 'rxjs';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserViewModel } from '../Model/UserModel';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  Token: string = "";
  errMsg: string="";
  constructor(private http: HttpClient) { }

  userViewModel: UserViewModel;

  login(Username: string, Password: string) {


    const user: UserViewModel = { userName: Username, userPassword: Password };

    return this.http.post("http://localhost:39521/api/Login", user)
      .map(user => {
        debugger;
        return user;
      });
  }
}