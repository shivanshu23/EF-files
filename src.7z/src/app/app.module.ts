import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { GetAllResourceComponent } from './get-all-resource/get-all-resource.component';
import { GetResourceDeatilsComponent } from './get-resource-deatils/get-resource-deatils.component';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { LoginService } from '../app/Services/login.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import {JwtInterceptor} from '../app/_helpers/jwt.interceptor';
import {AuthService} from '../app/_helpers/AuthService';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LogoutComponent } from './logout/logout.component';
import { CommonModule } from '@angular/common';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from  '@angular/platform-browser/animations';
import {DashboardComponent} from '../app/dashboard/dashboard.component';
import { MyBookingsComponent } from './my-bookings/my-bookings.component';
import { BookingDetailComponent } from './booking-detail/booking-detail.component';


@NgModule({
  declarations: [
    AppComponent,
    GetAllResourceComponent,
    GetResourceDeatilsComponent,
    LoginComponent,
    SignUpComponent,
    LogoutComponent,
    DashboardComponent,
    MyBookingsComponent,
    BookingDetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgbModule,
    CommonModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule
  ],
  providers: [LoginService,
    NgbCarouselConfig,
    AuthService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: JwtInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
