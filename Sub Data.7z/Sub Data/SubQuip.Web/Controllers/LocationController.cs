﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SubQuip.Common.CommonData;
using Microsoft.AspNetCore.Authorization;
using SubQuip.Business.Interfaces;
using SubQuip.ViewModel.Licence;
using SubQuip.ViewModel.Location;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using MongoDB.Bson.IO;
using SubQuip.ViewModel.Equipment;
using SubQuip.Common.Extensions;
using Newtonsoft.Json;
using SubQuip.ViewModel.User;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// Location Controller.
    /// </summary>
    [Produces("application/json")]
    [Route("api/Location/[Action]")]
    [ValidateModel]
    [Authorize]
    public class LocationController : Controller
    {
        private readonly ILocationService _locationManager;
        
        /// <summary>
        /// Initializes a new instance of the LocationController.
        /// </summary>
        /// <param name="locationManager"></param>
        public LocationController(ILocationService locationManager)
        {
            _locationManager = locationManager;
        }

        /// <summary>
        /// Get all Locations.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        [HttpGet]
        public IResult Locations(SearchSortModel search)
        {
            var locationList = _locationManager.GetAllLocations(search);
            return locationList;
        }

        /// <summary>
        /// Get a spesific location.
        /// </summary>
        /// <returns>Record of that loction.</returns>
        /// <param name="id">Identifier of the loction.</param>
        [HttpGet]
        [ProducesResponseType(typeof(LocationViewModel), (int)HttpStatusCode.OK)]
        public IResult Details(string id)
        {
            var locationRecords = _locationManager.GetLocationById(id);
            return locationRecords;
        }
        
        /// <summary>
        /// Create a Location.
        /// </summary>
        /// <param name="locationView"></param>
        /// <returns></returns>
        [HttpPost]
        public IResult Create([FromBody]LocationViewModel locationView)
        {
            var location = _locationManager.Create(locationView);
            return location;
        }

        /// <summary>
        /// Update a Location.
        /// </summary>
        /// <param name="locationView"></param>
        /// <returns></returns>
        [HttpPost]
        public IResult Update([FromBody]LocationViewModel locationView)
        {
            var location = _locationManager.Update(locationView);
            return location;
        }

        /// <summary>
        /// Delete a Location.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        public IResult Delete(string id)
        {
            var location = _locationManager.Delete(id);
            return location;
        }

        /// <summary>
        /// Delete All Locations.
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        [HttpDelete]
        public IResult DeleteAll([FromBody]UserLoginViewModel loginModel)
        {
            if (loginModel.UserName.Equals("test") && loginModel.UserPassword.Equals("test"))
            {
                return _locationManager.DeleteAllLocations();
            }
            return null;
        }


        /// <summary>
        /// Import licence data
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(LocationImportResult), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Import(IFormFile uploadFile)
        {
            var result = _locationManager.ImportLocations(uploadFile);
            return result;
        }

        /// <summary>
        /// Export all licence
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<LocationExportViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Export()
        {
            var result = _locationManager.ExportLocations();
            return result;
        }
    }
}