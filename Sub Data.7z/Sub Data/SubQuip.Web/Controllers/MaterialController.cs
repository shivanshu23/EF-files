﻿using Microsoft.AspNetCore.Mvc;
using SubQuip.Common.CommonData;
using Microsoft.AspNetCore.Authorization;
using SubQuip.Business.Interfaces;
using SubQuip.ViewModel.PartProperties;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using System.Linq;
using SubQuip.Common.Extensions;
using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using SubQuip.ViewModel.Material;
using SubQuip.ViewModel.TechSpecs;
using SubQuip.Common;
using SubQuip.Common.Enums;
using SubQuip.Common.Importer;
using SubQuip.ViewModel.Equipment;
using SubQuip.ViewModel.Request;
using SubQuip.ViewModel.User;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// Material controller.
    /// </summary>
    [Produces("application/json")]
    [Route("api/Material/[Action]")]
    [ValidateModel]
    [Authorize]
    public class MaterialController : Controller
    {

        private readonly IConfiguration _configuration;
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IMaterialService _materialService;

        /// <summary>
        /// Initializes a new instance of Material controller
        /// </summary>
        /// <param name="materialService">Material manager.</param>
        /// <param name="configuration">Configuration.</param>
        /// <param name="hostingEnvironment">Hosting environment.</param>
        public MaterialController(IMaterialService materialService, IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            _materialService = materialService;
            _configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
        }

        /// <summary>
        /// Search for materials.
        /// </summary>
        /// <returns>List of found materials.</returns>
        /// <param name="search">Search parameters.</param>
        [HttpGet]
        [ProducesResponseType(typeof(List<MaterialViewModel>), (int)HttpStatusCode.OK)]
        public IResult Materials(SearchSortModel search)
        {
            var materialList = _materialService.GetAllMaterials(search);
            return materialList;
        }

        /// <summary>
        /// Get a spesific material.
        /// </summary>
        /// <returns>Record of that material.</returns>
        /// <param name="id">Identifier of the material.</param>
        [HttpGet]
        [ProducesResponseType(typeof(MaterialViewModel), (int)HttpStatusCode.OK)]
        public IResult Details(string id)
        {
            var materialRecord = _materialService.GetMaterialById(id);
            return materialRecord;
        }

        /// <summary>
        /// Get Equipments For Material
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<EquipmentViewModel>), (int)HttpStatusCode.OK)]
        public IResult EquipmentsForMaterial(string id)
        {
            var materialRecord = _materialService.GetEquipmentsForMaterial(id);
            return materialRecord;
        }

        /// <summary>
        /// Create a new material.
        /// </summary>
        /// <returns>The created material.</returns>
        [HttpPost]
        public IResult Create()
        {
            IResult result = null;
            FileDetails fileModel = null;
            var materialViewModel = JsonConvert.DeserializeObject<MaterialViewModel>(Request.Form["model"]);
            if (materialViewModel != null)
            {
                var files = Request.Form.Files;
                if (files.Any())
                {
                    var file = files[0];
                    fileModel = FileHelper.GetFileDetails(file);
                }
            }
            result = _materialService.InsertMaterial(materialViewModel, fileModel);
            return result;
        }

        /// <summary>
        /// Upload the material document.
        /// </summary>
        /// <returns>The material document.</returns>
        [HttpPost]
        public IResult InsertMaterialDocument()
        {
            IResult result = null;
            var documentViewModel = JsonConvert.DeserializeObject<DocumentViewModel>(Request.Form["model"]);
            var fileList = new List<FileDetails>();
            if (documentViewModel != null)
            {
                var files = Request.Form.Files;
                foreach (var file in files)
                {
                    var fileModel = FileHelper.GetFileDetails(file);
                    fileModel.Title = documentViewModel.Title;
                    fileModel.Description = documentViewModel.Description;
                    fileList.Add(fileModel);
                }

                result = _materialService.SaveMaterialDocument(fileList, documentViewModel);
            }
            return result;
        }

        /// <summary>
        /// Update a material.
        /// </summary>
        /// <returns>The updated material model.</returns>
        [HttpPut]
        public IResult Update()
        {
            IResult result = null;
            FileDetails fileModel = null;
            var materialViewModel = JsonConvert.DeserializeObject<MaterialViewModel>(Request.Form["model"]);
            if (materialViewModel != null)
            {
                var files = Request.Form.Files;
                if (files.Any())
                {
                    var file = files[0];
                    fileModel = FileHelper.GetFileDetails(file);
                }
            }
            result = _materialService.UpdateMaterial(materialViewModel, fileModel);
            return result;
        }

        /// <summary>
        /// Delete a spesific material by its identifier.
        /// </summary>
        /// <param name="id">Identifier of the material.</param>
        [HttpDelete]
        public void Delete(string id)
        {
            _materialService.DeleteMaterial(id);
        }

        /// <summary>
        /// Manages the material part properties.
        /// </summary>
        /// <returns>The material part properties.</returns>
        /// <param name="partPropertyViewModel">Part property view model.</param>
        [HttpPut]
        public IResult ManageMaterialPartProperties([FromBody] PartPropertyViewModel partPropertyViewModel)
        {
            var result = _materialService.ManageMaterialPartProperties(partPropertyViewModel);
            return result;
        }

        /// <summary>
        /// Manages the material tech specs.
        /// </summary>
        /// <returns>The material tech specs.</returns>
        /// <param name="techSpecsViewModel">Tech specs view model.</param>
        [HttpPut]
        public IResult ManageMaterialTechSpecs([FromBody] TechSpecsViewModel techSpecsViewModel)
        {
            var result = _materialService.ManageMaterialTechnicalSpecs(techSpecsViewModel);
            return result;
        }

        /// <summary>
        /// Delete All Materials.
        /// </summary>
        /// <param name="loginModel"></param>
        /// <returns></returns>
        [HttpDelete]
        public IResult DeleteAll([FromBody]UserLoginViewModel loginModel)
        {
            if (loginModel.UserName.Equals("test") && loginModel.UserPassword.Equals("test"))
            {
                return _materialService.DeleteAllMaterial();
            }
            return null;
        }

        /// <summary>
        /// Delete Material Techincal Specification.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="techSpecId"></param>
        /// <returns></returns>
        [HttpDelete]
        public IResult DeleteMaterialTechnicalSpecification(string id, string techSpecId)
        {
            return _materialService.DeleteMaterialTechnicalSpecification(id, techSpecId);
        }

        /// <summary>
        /// Insert Material Request
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(MaterialRequestViewModel), (int)HttpStatusCode.OK)]
        public async Task<IResult> RequestMaterial()
        {
            IResult result = null;
            var requestViewModel = JsonConvert.DeserializeObject<MaterialRequestViewModel>(Request.Form["model"]);
            if (requestViewModel != null)
            {
                var fileList = new List<FileDetails>();
                var files = Request.Form.Files;
                foreach (var file in files)
                {
                    var fileModel = FileHelper.GetFileDetails(file);
                    fileList.Add(fileModel);
                }

                result = _materialService.InsertMaterialRequest(fileList, requestViewModel);
                if (result.Status == Status.Success)
                {
                    var emailOptions = PrepareEmailOptions(requestViewModel);
                    if (!string.IsNullOrEmpty(emailOptions.HtmlBody))
                    {
                        #region Append attach files
                        foreach (var file in files)
                        {
                            byte[] content = null;
                            using (var ms = new MemoryStream())
                            {
                                file.CopyTo(ms);
                                content = ms.ToArray();
                            }
                            emailOptions.Attachments.Add(new Attachment
                            {
                                Name = file.FileName,
                                ContentType = file.ContentType,
                                Content = content
                            });
                        }
                        #endregion

                        var response = await SendGridMailHelper.SendSingleEmailToMultipleRecipients(_configuration, emailOptions);
                        if (response.StatusCode == HttpStatusCode.Accepted)
                        {
                            result.Message += "; Mail sent.";
                        }
                        else
                        {
                            result.Message += "; Mail not sent to provided email.";
                        }
                    }
                    else
                    {
                        result.Message += "; Mail not sent, as email template not found";
                    }
                }
            }
            return result;
        }

        #region Private methods

        /// <summary>
        /// Prepare Email options for material requests
        /// </summary>
        /// <param name="requestViewModel"></param>
        /// <returns></returns>
        private EmailOptions PrepareEmailOptions(MaterialRequestViewModel requestViewModel)
        {
            var emailOptions = new EmailOptions
            {
                Template = MailTemplate.Material,
                PlainBody = string.Empty,
                Attachments = new List<Attachment>()
            };
            var msgBody = SendGridMailHelper.MailBody(_hostingEnvironment, emailOptions.Template);
            if (!string.IsNullOrEmpty(msgBody))
            {
                var link = string.Format("{0}feature/part-detail/material/{1}/overview", _configuration["AppUrl"], requestViewModel.RegardingId);
                emailOptions.Subject = "Request for Material/Part Received - SubQuip";
                emailOptions.CcMail = new MailUser { Name = "SubQuip", Email = _configuration["requestEmail"] };
                emailOptions.ToMailsList = requestViewModel.MailUsers;
                emailOptions.HtmlBody = msgBody.Replace("{MaterialNumber}", requestViewModel.MaterialNumber).
                                                Replace("{Link}", link).
                                                Replace("{FromDate}", requestViewModel.FromDate.ToString("dd-MM-yyyy")).
                                                Replace("{ToDate}", requestViewModel.ToDate.ToString("dd-MM-yyyy"));
            }
            return emailOptions;
        }

        #endregion

        /// <summary>
        /// Import material data
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(MaterialImportResult), (int)HttpStatusCode.OK)]
        public IResult Import(IFormFile uploadFile)
        {
            var result = _materialService.ImportMaterials(uploadFile);
            return result;
        }

        /// <summary>
        /// Export all materials
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<MaterialExportViewModel>), (int)HttpStatusCode.OK)]
        public IResult Export()
        {
            var result = _materialService.ExportMaterial();
            return result;
        }
    }
}
