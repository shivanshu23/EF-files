﻿using System;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SubQuip.Business.Interfaces;
using SubQuip.Common.CommonData;
using SubQuip.ViewModel.Statistics;
using SubQuip.Common.Enums;
using SubQuip.Data.Interfaces;
using System.Security.Claims;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// Statistics controller.
    /// </summary>
    [Produces("application/json")]
    [Route("api/statistics")]
    [ValidateModel]
    [Authorize]
    public class StatisticsController : Controller
    {
        private readonly IBillOfMaterialService _billOfMaterialsManagerService;
        private readonly IEquipmentService _equipmentManagerService;
        private readonly IMaterialService _materialManagerService;

        /// <summary>
        /// Stat controller
        /// </summary>
        /// <param name="billOfMaterialsManagerService"></param>
        /// <param name="equipmentManagerService"></param>
        public StatisticsController(IBillOfMaterialService billOfMaterialsManagerService, IEquipmentService equipmentManagerService, IMaterialService materialManagerService)
        {
            _billOfMaterialsManagerService = billOfMaterialsManagerService;
            _equipmentManagerService = equipmentManagerService;
            _materialManagerService = materialManagerService;

        }

        /// <summary>
        /// Get Statistics 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IResult GetStats()
        {
            var strMessage = string.Empty;
            var stats = new Statistics();
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var latestSearchModel = new SearchSortModel
                {
                    SortColumn = Constants.CreatedDate,
                    SortDirection = SortDirection.Desc,
                    Page = 1,
                    PageSize = 5
                };
                // Number of BOMS
                try
                {
                    stats.NumBoms = _billOfMaterialsManagerService.CountNumBillOfMaterial();
                }
                catch (Exception numBomsEx)
                {
                    stats.NumBoms = 0;
                    strMessage += numBomsEx.Message + " , ";
                }
                // Number of completed BOMS
                try
                {
                    stats.NumBomsCompleted = _billOfMaterialsManagerService.CountBOMNumCompleted();
                }
                catch (Exception numBomsCompletedEx)
                {
                    stats.NumBomsCompleted = 0;
                    strMessage += numBomsCompletedEx.Message + " , ";
                }
                // Number of BOMS in progress
                try
                {
                    stats.NumBomsInProgress = _billOfMaterialsManagerService.CountBOMNumInProgress();
                }
                catch (Exception numBomsInProgressEx)
                {
                    stats.NumBomsInProgress = 0;
                    strMessage += numBomsInProgressEx.Message + " , ";
                }
                // Number of equipments
                try
                {
                    stats.NumEquipments = _equipmentManagerService.CountNumEquipments();
                }
                catch (Exception numEquipmentsEx)
                {
                    stats.NumEquipments = 0;
                    strMessage += numEquipmentsEx.Message + " , ";
                }
                // Number of equipments for partner
                try
                {
                    stats.NumEquipmentForPartner = _equipmentManagerService.CountNumEquipmentsPerPartner();
                }
                catch (Exception numEquipmentsFrPartnerEx)
                {
                    stats.NumEquipmentForPartner = null;
                    strMessage +=  numEquipmentsFrPartnerEx.Message + " , ";
                }
                // Number of equipments with documentation
                try
                {
                    stats.NumEquipmentsWithDocumentation = _equipmentManagerService.CountNumEquipmentsWithDocument();
                }
                catch (Exception numEquipmentsWithDoc)
                {
                    stats.NumEquipmentsWithDocumentation = 0;
                    strMessage += numEquipmentsWithDoc.Message + " , ";
                }
                // recently added equipments
                try
                {
                    stats.NumRecentEquipments = _equipmentManagerService.CountNumEquipmentsAddedLastWeek();
                }
                catch (Exception numEquipmentsRecentEx)
                {
                    stats.NumRecentEquipments = 0;
                    strMessage += numEquipmentsRecentEx.Message + " , ";
                }

                // Number of materials
                try
                {
                    stats.NumMaterials = _materialManagerService.CountNumMaterials();
                }
                catch (Exception numMaterialsEx)
                {
                    stats.NumMaterials = 0;
                    strMessage += numMaterialsEx.Message + " , ";
                }

                // Number of materials with documentation
                try
                {
                    stats.NumMaterialsWithDocumentation = _materialManagerService.CountNumMaterialsWithDocument();
                }
                catch (Exception numMaterialsDocEx)
                {
                    stats.NumMaterialsWithDocumentation = 0;
                    strMessage += numMaterialsDocEx.Message + " , ";
                }

                // Number of materials Recently added
                try
                {
                    stats.NumRecentMaterials = _materialManagerService.CountNumMaterialsAddedLastWeek();
                }
                catch (Exception numMaterialsRecentEx)
                {
                    stats.NumRecentMaterials = 0;
                    strMessage += numMaterialsRecentEx.Message + " , ";
                }

                // last five BOM requests
                try
                {
                    stats.LastFiveRequests = _billOfMaterialsManagerService.GetSearchedBom(latestSearchModel, string.Empty);
                }
                catch (Exception numMaterialsRecentEx)
                {
                    stats.LastFiveRequests = null;
                    strMessage += numMaterialsRecentEx.Message + " , ";
                }

                result.Body = stats;
            }
            catch (Exception e)
            {
                strMessage += e.Message;
                result.Status = Status.Fail;
            }
            finally
            {
                result.Message = strMessage.TrimEnd(',');
            }
            return result;
        }
    }
}
