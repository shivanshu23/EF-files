﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SubQuip.Common.CommonData;
using Microsoft.AspNetCore.Authorization;
using SubQuip.Business.Interfaces;
using SubQuip.ViewModel.Licence;

namespace SubQuip.WebApi.Controllers
{
    /// <summary>
    /// Location Controller.
    /// </summary>
    [Produces("application/json")]
    [Route("api/Licence/[Action]")]
    [ValidateModel]
    [Authorize]
    public class LicenceController : Controller
    {
        private readonly ILicenceService _licenceManager;

        /// <summary>
        /// Initializes a new instance of the licenceController.
        /// </summary>
        /// <param name="licenceManager"></param>
        public LicenceController(ILicenceService licenceManager)
        {
            _licenceManager = licenceManager;
        }

        /// <summary>
        /// Get all licence.
        /// </summary>
        /// <param name="search"></param>
        /// <returns></returns>
        [HttpGet]
        public IResult Licences(SearchSortModel search)
        {
            var licenceList = _licenceManager.GetAllLicence(search);
            return licenceList;
        }

        /// <summary>
        /// Import licence data
        /// </summary>
        /// <param name="uploadFile"></param>
        /// <returns></returns>
        [HttpPost]
        [ProducesResponseType(typeof(LicenceImportResult), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Import(IFormFile uploadFile)
        {
            var result = _licenceManager.ImportLicences(uploadFile);
            return result;
        }

        /// <summary>
        /// Export all licence
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<LicenceExportViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public IResult Export()
        {
            var result = _licenceManager.ExportLicence();
            return result;
        }
    }
}