﻿using System.Security.Principal;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using SubQuip.Business.Interfaces;
using SubQuip.Business.Logic;
using SubQuip.Data.Interfaces;
using SubQuip.Data.Logic;

namespace SubQuip.WebApi
{
    public static class BuildUnityContainer
    {
        public static IServiceCollection RegisterAddTransient(IServiceCollection services)
        {
            services.AddTransient<IHttpContextAccessor, HttpContextAccessor>();
            services.AddTransient<IPrincipal>(
                provider => provider.GetService<IHttpContextAccessor>().HttpContext.User);

            #region Repository
            services.AddTransient<IEquipmentRepository, EquipmentRepository>();
            services.AddTransient<IMaterialRepository, MaterialRepository>();
            services.AddTransient<IRequestRepository, RequestRepository>();
            services.AddTransient<IBillOfMaterialRepository, BillOfMaterialRepository>();
            services.AddTransient<IFileRepository, FileRepository>();
            services.AddTransient<IGraphRepository, GraphRepository>();
            services.AddTransient<IPartnerRepository, PartnerRepository>();
            services.AddTransient<ILocationRepository, LocationRepository>();
            services.AddTransient<ILicenceRepository, LicenceRepository>();
            services.AddTransient<IUserRepository, UserRepository>();
            #endregion

            #region Services
            services.AddTransient<IEquipmentService, EquipmentService>();
            services.AddTransient<IMaterialService, MaterialService>();
            services.AddTransient<IRequestService, RequestService>();
            services.AddTransient<IBillOfMaterialService, BillOfMaterialService>();
            services.AddTransient<IFileService, FileService>();
            services.AddTransient<IPartnerService, PartnerService>();
            services.AddTransient<ILocationService, LocationService>();
            services.AddTransient<ILicenceService, LicenceService>();
            services.AddTransient<IUserService, UserService>();
            #endregion

            return services;
        }
    }
}
