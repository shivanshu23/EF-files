﻿using System;

namespace SubQuip.Common.CommonData
{
    public class UserClaim
    {
        public string Name { get; set; }

        public string Email { get; set; }

    }
}
