﻿using System.Collections.Generic;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDBGames.Model;

namespace MongoDBGames.Repository
{
    public interface IItemRepository: IRepository<Items>
    {
        IEnumerable<ItemsViewModel> GetAllItems();
        Items GetItemById(ObjectId id);
        void CreateItem(Items game);
        Items UpdateItem(ObjectId id , Items item);
        Items DeleteItem(ObjectId id);
    }
}