﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;

namespace GCRieber.API
{
    public partial class Startup
    {
        /// <summary>
        /// In development mode, we must ensure that unauthenticated users have access.
        /// </summary>
        /// <param name="services"></param>
        private void ConfigureAuth(IServiceCollection services)
        {
            services
                .AddAuthorization(options =>
                {
                    options.DefaultPolicy = new AuthorizationPolicyBuilder()
                        .RequireAuthenticatedUser()
                        .AddAuthenticationSchemes("B2C")
                        .Build();
                })
                .AddAuthentication(sharedOptions =>
                {
                    sharedOptions.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                    sharedOptions.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                    sharedOptions.DefaultForbidScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer("B2C", option =>
                {
                    option.Authority = "https://grceexternal.b2clogin.com/tfp/logintest.gcrieber.com/B2C_1_gcr_portal_login/v2.0";
                    option.Audience = Configuration["AzureB2C:Audience"];
                    option.Events = new JwtBearerEvents
                    {
                        OnTokenValidated = context =>
                        {
                            return Task.CompletedTask;
                        },
                        OnAuthenticationFailed = context =>
                        {
                            return Task.CompletedTask;
                        }
                    };
                });
        }


    }
}