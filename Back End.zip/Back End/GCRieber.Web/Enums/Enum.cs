﻿using System.ComponentModel;

namespace GCRieber.API.Enums
{
    public enum Status { Fail, Success, Error }

    public enum Operation
    {
        Create = 1,
        Read = 2,
        Update = 3,
        Delete = 4
    }

    /// <summary>
    /// Reservation status
    /// </summary>
    public enum ReservationStatus
    {
        /// <summary>
        /// 1 = reservation completed. Generally all reservations are completed except when the reservation process was not finished (e.g. required online payment missing or shopping cart not checked out). This status means that the period is reserved and unavailable for other customers
        /// </summary>
        [Description("Reservation completed")]
        Completed = 1,
        /// <summary>
        /// 2 = user's email address has been verified.
        /// </summary>
        [Description("User's email address has been verified")] EmailVerified = 2,
        /// <summary>
        /// 4 = reservation confirmed (self-confirmed, e.g. with a payment or confirmed by the admin)
        /// </summary>
        [Description("Reservation confirmed")] Confirmed = 4,
        /// <summary>
        ///  8 = cancelled by administrator
        /// </summary>
        [Description("Cancelled by administrator")] CancelByAdmin = 8,
        /// <summary>
        /// 16 = cancelled by user
        /// </summary>
        [Description("Cancelled by user")] CancelByUser = 16,
        /// <summary>
        ///  64 = fraudulent reservation
        /// </summary>
        [Description("Fraudulent reservation")] FraudulentReservation = 64,
        /// <summary>
        ///   128 = conflict. Conflicts can happen if e.g. you add vacation for a period for which there already exists a reservation.
        /// </summary>
        [Description("Conflict")] Conflict = 128,
        /// <summary>
        /// 512 = reservation was cancelled automatically based on resource rules
        /// </summary>
        [Description("Reservation was cancelled automatically based on resource rules")] AutomaticCancel = 512,
        /// <summary>
        /// 2048 = quotation
        /// </summary>
        [Description("Quotation")] Quotation = 2048,
        /// <summary>
        ///  0 = not completed
        /// </summary>
        [Description("Not completed")] NotCompleted = 0,
        /// <summary>
        /// 32 = client checked in
        /// </summary>
        [Description("Client checked in")] CheckedIn = 32,
        /// <summary>
        /// 1024 = client checked out 
        /// </summary>
        [Description("Client checked out")] CheckedOut = 1024,

        /// <summary>
        /// 3 = Booking completed and user's email verified.
        /// </summary>
        [Description("Reserved + Email address verified")]
        CompletedEmailVerified = Completed + EmailVerified,

        /// <summary>
        /// 7 = Completed, email verified and  reservation confirmed 
        /// </summary>
        [Description("Reserved + Email address verified + Confirmed")]
        CompeletedEmailVerifiedConfirmed = Completed + EmailVerified + Confirmed
    }


    /// <summary>
    /// Detail level for user reservation info
    /// </summary>
    public enum DetailLevels
    {
        /// <summary>
        /// reservation info (all except for price and custom properties)
        /// </summary>
        ReservationInfo = 1,    //Default value

        /// <summary>
        /// reservation properties (reservation form items)
        /// </summary>
        ReservationProperties = 2,

        /// <summary>
        /// pricing info, payments and flexible package assignments
        /// </summary>
        PricingInfo = 4,

        /// <summary>
        /// custom resource properties
        /// </summary>
        ResourceProperties = 8,

        /// <summary>
        /// site properties
        /// </summary>
        SiteProperties = 16,

        /// <summary>
        /// user properties
        /// </summary>
        UserProperties = 32,

        /// <summary>
        /// site properties = 12
        /// </summary>
        PriceLocation = PricingInfo + ResourceProperties
    }

    /// <summary>
    /// Resource detail level enums
    /// </summary>
    public enum ResourceDetailLevels
    {
        /// <summary>
        /// Resource name
        /// </summary>
        [Description("Resource name")]
        ResourceName = 1,

        /// <summary>
        /// Resource settings  (quantity, site_id, confirmation_type, category, unit_names, resource admin info)
        /// </summary>
        [Description("Resource settings  (quantity, site_id, confirmation_type, category, unit_names, resource admin info)")]
        ResourceSettings = 2,

        /// <summary>
        /// Resource properties (resource-specific properties)
        /// </summary>
        [Description("Resource properties (resource-specific properties)")]
        ResourceProperties = 4,

        /// <summary>
        /// Resource photos
        /// </summary>
        [Description("Resource photos")]
        ResourcePhotos = 8
    }

}
