﻿namespace GCRieber.API.Helpers
{

    public static class CommonErrorMessages
    {
        public const string UnknownError = "Sorry, we have encountered an error.";
        public const string BadRequest = "Invalid Request";
        public const string NoResultFound = "No Result Found";
        public const string SomethingWentWrong = "Some thing went wrong";
    }

    public static class PlanyoEndpoints
    {
        public const string ListResources = "list_resources";
        public const string GetResourceInfo = "get_resource_info";
        public const string ListReservations = "list_reservations";
        public const string GetReservationData = "get_reservation_data";
        public const string DoReservationAction = "do_reservation_action";
        public const string ModifyReservation = "modify_reservation";
        public const string MakeReservation = "make_reservation";
        public const string AddUser = "add_user";
        public const string GetUserData = "get_user_data";
        public const string ResourceSearch = "resource_search";
    }

    /// <summary>
    /// Reservation actions
    /// </summary>
    public static class ReservationActions
    {
        /// <summary>
        /// email address verified
        /// </summary>
        public const string Verify = "Verify";

        /// <summary>
        /// Confirm
        /// </summary>
        public const string Confirm = "Confirm";

        /// <summary>
        /// automatically confirm this and all future reservations of this user
        /// </summary>
        public const string Preapprove = "Preapprove";

        /// <summary>
        /// cancel this reservation and prevent this customer from making future reservations
        /// </summary>
        public const string Fraud = "Fraud";

        /// <summary>
        /// reservation cancelled by the administrator
        /// </summary>
        public const string Cancel = "Cancel";

        /// <summary>
        /// reservation cancelled by the customer
        /// </summary>
        public const string UserCancel = "User_cancel";

        /// <summary>
        /// customer is checking in
        /// </summary>
        public const string Checkin = "Checkin";

        /// <summary>
        /// remove the checked-in status
        /// </summary>
        public const string ClearCheckin = "Clear_checkin";

        /// <summary>
        /// customer is checking out
        /// </summary>
        public const string Checkout = "Checkout";

        /// <summary>
        /// customer hasn't showed up
        /// </summary>
        public const string Noshow = "Noshow";

        /// <summary>
        /// remove the no - show status
        /// </summary>
        public const string ClearNoshow = "Clear_noshow";

        /// <summary>
        /// remove the confirmed status
        /// </summary>
        public const string Unconfirm = "Unconfirm";

        /// <summary>
        /// remove the canceled status
        /// </summary>
        public const string Uncancel = "Uncancel";

        /// <summary>
        /// remove both the reserved and confirmed statuses
        /// </summary>
        public const string MakeNotCompleted = "Make_not_completed";

        /// <summary>
        /// remove the reserved status and mark reservation as a quotation
        /// </summary>
        public const string MarkAsQuote = "Mark_as_quote";
    }


}
