﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using Microsoft.AspNetCore.Http;

namespace GCRieber.API.Helpers
{
    /// <summary>
    /// Application helper methods
    /// </summary>
    public static class AppHelper
    {
        /// <summary>
        /// Split on all non-word characters.
        /// </summary>
        /// <param name="s"></param>
        /// <returns>Returns an array of all the words.</returns>
        public static string[] SplitWords(string s)
        {
            // @      special verbatim string syntax
            // \W+    one or more non-word characters together
            return Regex.Split(s, @"\W+");
        }

        /// <summary>
        /// Check string contains only alphabets
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static bool IsAlpha(string s)
        {
            var isAlpha = Regex.IsMatch(s, @"^[a-zA-Z]+$");
            return isAlpha;
        }

        /// <summary>
        /// String contains only numeric
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static bool IsNumeric(string s)
        {
            var isNumeric = Regex.IsMatch(s, @"^[0-9]+$");
            return isNumeric;
        }

        /// <summary>
        /// Attempt to lookup remote IP address by looking at the header X-Forwarded-For, then the HttpContextAccessor.
        /// </summary>
        /// <param name="request">HTTP request</param>
        /// <param name="accessor">HTTP context accessor</param>
        /// <param name="ipAddress">value to be set</param>
        /// <returns>IP address</returns>
        public static bool TryLookupRemoteIpAddress(HttpRequest request, IHttpContextAccessor accessor, out string ipAddress)
        {
            ipAddress = "";
            if (request?.Headers == null)
            {
                return false;
            }
            var xForwardedFor = request.Headers["X-Forwarded-For"].ToString();
            if (!string.IsNullOrEmpty(xForwardedFor))
            {
                ipAddress = xForwardedFor.Contains(",") ? xForwardedFor.Split(',')[0] : xForwardedFor;
                return true;
            }

            if (accessor?.HttpContext?.Connection?.RemoteIpAddress == null)
            {
                return false;
            }
            var remoteIpAddress = accessor.HttpContext.Connection.RemoteIpAddress.ToString();
            ipAddress = remoteIpAddress.Contains(",") ? remoteIpAddress.Split(',')[0] : remoteIpAddress;
            return true;
        }

        /// <summary>
        /// Time stamp for planyo api
        /// </summary>
        /// <returns></returns>
        public static int TimeStamp()
        {
            var unixTimeStamp = (int)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            return unixTimeStamp;
        }

        /// <summary>
        /// Create md5 hash
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string CreateHash(string input)
        {
            var hash = new StringBuilder();
            var md5Provider = new MD5CryptoServiceProvider();
            var bytes = md5Provider.ComputeHash(new UTF8Encoding().GetBytes(input));

            foreach (var t in bytes)
            {
                hash.Append(t.ToString("x2"));  //formats the string as 2 uppercase hexadecimal characters.
            }
            return hash.ToString();
        }

        /// <summary>
        /// Get id of request user
        /// </summary>
        /// <param name="identity"></param>
        /// <returns></returns>
        public static string GetActiveUserId(this ClaimsIdentity identity)
        {
            if (identity != null)
            {
                if (identity.Claims.Any())
                {
                    var contactIdClaim = identity.Claims.SingleOrDefault(t => t.Type == "extension_contactId");
                    return contactIdClaim != null ? contactIdClaim.Value : string.Empty;
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Get the email of request user
        /// </summary>
        /// <param name="identity"></param>
        /// <returns></returns>
        public static string GetActiveUserEmail(this ClaimsIdentity identity)
        {
            if (identity != null)
            {
                if (identity.Claims.Any())
                {
                    var email = identity.Claims.SingleOrDefault(t => t.Type == "emails");
                    return email != null ? email.Value : string.Empty;
                }
            }
            return string.Empty;
        }

        public static string GetDescription<T>(this T e) where T : IConvertible
        {
            if (!(e is Enum)) return null; // could also return string.Empty
            var type = e.GetType();
            var values = System.Enum.GetValues(type);
            foreach (int val in values)
            {
                if (val == e.ToInt32(CultureInfo.InvariantCulture))
                {
                    var memInfo = type.GetMember(type.GetEnumName(val));
                    var descriptionAttribute = memInfo[0]
                        .GetCustomAttributes(typeof(DescriptionAttribute), false)
                        .FirstOrDefault() as DescriptionAttribute;

                    if (descriptionAttribute != null)
                    {
                        return descriptionAttribute.Description;
                    }
                }
            }
            return null; // could also return string.Empty
        }

        /// <summary>
        /// Azure Storage image path
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string StoragePath(string path)
        {
            if (string.IsNullOrEmpty(path))
                return string.Empty;

            var result = Path.GetFileName(path);
            result = $"static/uploads/{DecodeUrl(result)}";
            return result;
        }

        public static T DictionaryToObject<T>(IDictionary<string, object> dict, string[] ignoreProperties = null) where T : new()
        {
            var t = new T();
            PropertyInfo[] properties = t.GetType().GetProperties();

            foreach (PropertyInfo property in properties)
            {
                if (!dict.Any(x =>
                    {
                        return ignoreProperties != null && (x.Key.Equals(property.Name, StringComparison.InvariantCultureIgnoreCase) &&
                                                            !ignoreProperties.Contains(x.Key));
                    }))
                    continue;

                KeyValuePair<string, object> item = dict.First(x => x.Key.Equals(property.Name, StringComparison.InvariantCultureIgnoreCase));

                // Find which property type (int, string, double? etc) the CURRENT property is...
                Type tPropertyType = t.GetType().GetProperty(property.Name).PropertyType;

                // Fix nullables...
                Type newT = Nullable.GetUnderlyingType(tPropertyType) ?? tPropertyType;

                // ...and change the type
                object newA = Convert.ChangeType(item.Value, newT);
                t.GetType().GetProperty(property.Name).SetValue(t, newA, null);
            }
            return t;
        }

        /// <summary>
        /// Text decoding
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string DecodeText(string text)
        {
            if (!string.IsNullOrEmpty(text))
                return HttpUtility.HtmlDecode(text);
            return string.Empty;
        }

        /// <summary>
        /// Url decode
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string DecodeUrl(string path)
        {
            if (!string.IsNullOrEmpty(path))
                return HttpUtility.UrlDecode(path);
            return string.Empty;
        }
    }
}