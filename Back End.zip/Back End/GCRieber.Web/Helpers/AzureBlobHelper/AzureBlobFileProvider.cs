﻿using System;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Primitives;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;

namespace GCRieber.API.Helpers.AzureBlobHelper
{
    /// <summary>
    /// Azure blob file provider
    /// </summary>
    public class AzureBlobFileProvider : IFileProvider
    {
        private readonly CloudBlobContainer _container;

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="azureBlobOptions"></param>
        public AzureBlobFileProvider(AzureBlobOptions azureBlobOptions)
        {
            CloudBlobClient blobClient;
            if (azureBlobOptions.ConnectionString != null && CloudStorageAccount.TryParse(azureBlobOptions.ConnectionString, out var cloudStorageAccount))
            {
                blobClient = cloudStorageAccount.CreateCloudBlobClient();
            }
            else if (azureBlobOptions.BaseUri != null && azureBlobOptions.Token != null)
            {
                blobClient = new CloudBlobClient(azureBlobOptions.BaseUri, new StorageCredentials(azureBlobOptions.Token));
            }
            else
            {
                throw new ArgumentException("One of the following must be set: 'ConnectionString' or 'BaseUri'+'Token'!");
            }
            _container = blobClient.GetContainerReference(azureBlobOptions.DocumentContainer);
        }

        /// <summary>
        /// Get the directory contents
        /// </summary>
        /// <param name="subpath"></param>
        /// <returns></returns>
        public IDirectoryContents GetDirectoryContents(string subpath)
        {
            var blob = _container.GetDirectoryReference(subpath.TrimStart('/').TrimEnd('/'));
            return new AzureBlobDirectoryContents(blob);
        }

        /// <summary>
        /// Get the blob file info
        /// </summary>
        /// <param name="subpath"></param>
        /// <returns></returns>
        public IFileInfo GetFileInfo(string subpath)
        {
            var blob = _container.GetBlockBlobReference(subpath.TrimStart('/').TrimEnd('/'));
            return new AzureBlobFileInfo(blob);
        }

        /// <summary>
        /// Not implemented
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        public IChangeToken Watch(string filter) => throw new NotImplementedException();
    }
}

