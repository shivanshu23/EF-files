﻿using System;
using System.IO;
using Microsoft.Extensions.FileProviders;
using Microsoft.WindowsAzure.Storage.Blob;

namespace GCRieber.API.Helpers.AzureBlobHelper
{
    /// <summary>
    /// Azure blob file info
    /// </summary>
    public class AzureBlobFileInfo : IFileInfo
    {
        private readonly CloudBlockBlob _blockBlob;

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="blob"></param>
        public AzureBlobFileInfo(IListBlobItem blob)
        {
            Exists = true;
            switch (blob)
            {
                case CloudBlobDirectory d:
                    IsDirectory = true;
                    Name = ((CloudBlobDirectory)blob).Prefix.TrimEnd('/');
                    PhysicalPath = d.StorageUri.PrimaryUri.ToString();
                    break;

                case CloudBlockBlob b:
                    b.FetchAttributes();
                    Length = b.Properties.Length;
                    PhysicalPath = b.Uri.ToString();
                    Name = !string.IsNullOrEmpty(b.Parent.Prefix) ? b.Name.Replace(b.Parent.Prefix, "") : b.Name;
                    LastModified = b.Properties.LastModified ?? DateTimeOffset.MinValue;
                    _blockBlob = b;
                    break;
            }
        }

        /// <summary>
        /// Stream of file content
        /// </summary>
        /// <returns></returns>
        public Stream CreateReadStream()
        {
            var stream = new MemoryStream();
            _blockBlob.DownloadToStream(stream);
            stream.Position = 0;
            return stream;
        }

        /// <summary>
        /// File existance
        /// </summary>
        public bool Exists { get; }

        /// <summary>
        /// File length
        /// </summary>
        public long Length { get; }

        /// <summary>
        /// Storage file path
        /// </summary>
        public string PhysicalPath { get; }

        /// <summary>
        /// File Name
        /// </summary>
        public string Name { get; }

        /// <summary>
        /// Last modified date of file
        /// </summary>
        public DateTimeOffset LastModified { get; }

        /// <summary>
        /// Directory or file
        /// </summary>
        public bool IsDirectory { get; }

    }
}

