﻿using System;

namespace GCRieber.API.Helpers.AzureBlobHelper
{
    /// <summary>
    /// Blob options
    /// </summary>
    public class AzureBlobOptions
    {
        /// <summary>
        /// Storage base uri
        /// </summary>
        public Uri BaseUri { get; set; }

        /// <summary>
        /// Storage SAS token
        /// </summary>
        public string Token { get; set; }

        /// <summary>
        /// Container
        /// </summary>
        public string DocumentContainer { get; set; }

        /// <summary>
        /// Storage connection string
        /// </summary>
        public string ConnectionString { get; set; }
    }
}