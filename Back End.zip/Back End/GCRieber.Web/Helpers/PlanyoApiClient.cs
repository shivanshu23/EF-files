﻿using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using RestSharp;

namespace GCRieber.API.Helpers
{
    /// <summary>
    /// Planyo settings
    /// </summary>
    public class PlanyoApiClient
    {

        #region Private properties

        /// <summary>
        /// Planyo api base url
        /// </summary>
        private string ApiBaseUrL { get; set; }

        /// <summary>
        /// Planyo api key
        /// </summary>
        private string ApiKey { get; }

        /// <summary>
        /// Planyo api hash key
        /// it is to use only if hash is enabled
        /// </summary>
        private string ApiHashKey { get; }

        #endregion

        /// <summary>
        /// Initialize the planyo settings
        /// </summary>
        /// <param name="configuration"></param>
        public PlanyoApiClient(IConfiguration configuration)
        {
            ApiKey = configuration["Planyo:ApiKey"];
            ApiHashKey = configuration["Planyo:Hashkey"];
            ApiBaseUrL = $"{configuration["PlanyoApiUrl"]}?method=";
        }

        /// <summary>
        /// Execute api async
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="request"></param>
        /// <param name="methodName"></param>
        /// <returns></returns>
        public Task<T> ExecuteApiAsync<T>(RestRequest request, string methodName) where T : new()
        {
            var baseUrl = ApiBaseUrL + methodName;
            if (!string.IsNullOrEmpty(ApiHashKey))
            {
                var unixTimeStamp = AppHelper.TimeStamp();
                var hashToString = $"{ApiHashKey}{unixTimeStamp}{methodName}";
                var md5Hash = AppHelper.CreateHash(hashToString);

                request.AddParameter("hash_timestamp", unixTimeStamp);
                request.AddParameter("hash_key", md5Hash);
            }


            var client = new RestClient(baseUrl);
            var taskCompletionSource = new TaskCompletionSource<T>();
            request.AddParameter("api_key", ApiKey);
            request.AddHeader("content-type", "application/json");
            client.ExecuteAsync<T>(request, (response) =>
            {
                if (response.ErrorException != null)
                    taskCompletionSource.TrySetException(response.ErrorException);
                else
                    taskCompletionSource.TrySetResult(response.Data);
                //taskCompletionSource.SetResult(response.Data)
            });
            return taskCompletionSource.Task;
        }
    }
}
