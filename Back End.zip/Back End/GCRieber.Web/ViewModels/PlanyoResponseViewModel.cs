﻿using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Planyo response view model
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class PlanyoResponseViewModel<T>
    {
        /// <summary>
        /// Response code
        /// </summary>
        [JsonProperty("response_code")]
        public int ResponseCode { get; set; }

        /// <summary>
        /// Response message
        /// </summary>
        [JsonProperty("response_message")]
        public string ResponseMessage { get; set; }

        /// <summary>
        /// Resource list json
        /// </summary>
        [JsonProperty("data")]
        public T Data { get; set; }
    }
}
