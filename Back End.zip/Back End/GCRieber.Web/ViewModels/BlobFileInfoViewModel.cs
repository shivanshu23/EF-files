﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GCRieber.API.Helpers.AzureBlobHelper;
using Microsoft.Extensions.FileProviders;

namespace GCRieber.API.ViewModels
{
    public class BlobFileInfoViewModel
    {
        public IFileInfo FileInfo { get; set; }

        //public byte[] FileBytes { get; set; }

        public string FileContent { get; set; }
    }
}
