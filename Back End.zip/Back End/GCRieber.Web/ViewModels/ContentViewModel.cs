﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using GCRieber.API.Helpers;
using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Content file response
    /// </summary>
    public class ContentFileResponseViewModel
    {
        /// <summary>
        /// Resource list json
        /// </summary>
        [JsonProperty("data")]
        public List<ContentViewModel> Data { get; set; } = new List<ContentViewModel>();
    }


    /// <summary>
    /// Index json file content
    /// </summary>
    public class ContentViewModel
    {
        /// <summary>
        /// content id
        /// </summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>
        /// content name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// date
        /// </summary>
        [JsonProperty("date")]
        public string Date { get; set; }

        private string _image;
        /// <summary>
        /// image path
        /// </summary>
        [JsonProperty("image")]
        public string Image
        {
            get => _image;
            set => _image = AppHelper.StoragePath(value);
        }

        /// <summary>
        /// ingress
        /// </summary>
        [JsonProperty("ingress")]
        public string Ingress { get; set; }

        /// <summary>
        /// link text
        /// </summary>
        [JsonProperty("link_text")]
        public string LinkText { get; set; }

        /// <summary>
        /// tag
        /// </summary>
        [JsonProperty("tag")]
        public string Tag { get; set; }

        private string _text;
        /// <summary>
        /// text
        /// </summary>
        [JsonProperty("text")]
        public string Text
        {
            get => _text;
            set => _text = AppHelper.DecodeText(value);
        }

        private string _permalink;

        /// <summary>
        /// perma link
        /// </summary>
        [JsonProperty("permalink")]
        public string Permalink
        {
            get => _permalink;
            set => _permalink = AppHelper.DecodeUrl(value);
        }
    }
}
