﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    public class UserDataViewModel
    {
        /// <summary>
        /// User ID
        /// </summary>
        [JsonProperty("id")]
        public int Id { get; set; }

        /// <summary>
        /// User Email
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// First name of user
        /// </summary>
        [JsonProperty("first_name")]
        public string FirstName { get; set; }
    }

    /// <summary>
    /// Create new user data model
    /// </summary>
    public class CreateUserResponseViewModel
    {
        /// <summary>
        /// Status of reservation
        /// </summary>
        [JsonProperty("user_id")]
        public int User_id { get; set; }

        /// <summary>
        /// Status of reservation
        /// </summary>
        [JsonProperty("is_new")]
        public int Is_new { get; set; }

    }
}
