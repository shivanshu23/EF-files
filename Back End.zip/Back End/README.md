# GCRieber

GCRieber backend, API

## How to use :

* Git clone the repo at system drive.
* Build the project to download the required packages and dependencies
* For Planyo Api to work, need to Set up "Planyo_ApiKey" and "Planyo_Hashkey" Environment Variables on machine. Setup link : https://www.java.com/en/download/help/path.xml
* Remember do not add the "Planyo_Hashkey" in environment variable if hash key is not generated or delete the key.
* For API Authorization, need to add "AAD_Audience" named variable in Environment variables with value.
* For Content endpoint results, need to add "Azure_StorageConnectionString" named variable in Environment variables with value.
* Run the project using f5 button.
